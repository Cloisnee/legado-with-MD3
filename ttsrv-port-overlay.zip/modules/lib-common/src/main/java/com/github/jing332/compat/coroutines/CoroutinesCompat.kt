package com.github.jing332.compat.coroutines

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** 替代 com.drake.net.utils.withIO / withMain */
suspend fun <T> withIO(block: suspend () -> T): T = withContext(Dispatchers.IO) { block() }

suspend fun <T> withMain(block: suspend () -> T): T = withContext(Dispatchers.Main) { block() }
