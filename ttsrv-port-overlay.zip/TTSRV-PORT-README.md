# TTS-Server → 阅读（legado MD3）移植 · 阶段1 初始文件树

> 2026-09-14 · 配套文档：
> - `/workspace/阶段1_施工清单_libtts搬运与Rhino对齐.md`（施工总纲）
> - `/workspace/ttssrv_to_legadoMD3_评估与方案.md`（总体方案）
> - 来源快照：`/workspace/refs/tts-server-src/`（jing332/tts-server-android @ compose 49b4a7c334）

本目录是**可直接拷入阅读工程的三个库模块**（A 档搬运 + B 档适配已做）：

```
port/
├── modules/
│   ├── lib-common/   # 共 23 个 kt：基础工具/音频解码/日志垫片/网络桥/目录策略
│   ├── lib-script/   # 共 38 个 kt：Rhino 运行时 + ttsrv 桥（JS 沙箱/黑名单/文件/网络/WS）
│   └── lib-tts/      # 共 24 个 kt：插件引擎（getAudio/getAudioV2）+ 最小实体
└── _stage2_not_ported/  # 阶段2+ 待搬清单（含 JSeekBar/JSpinner/JTextInput 等）
```

---

## 一、集成步骤（4 步）

1. **拷贝**：把 `modules/` 下的 `lib-common`、`lib-script`、`lib-tts` 三个目录拷进阅读工程的 `modules/` 下。
2. **注册**：在 `settings.gradle.kts` 中加入：
   ```kotlin
   include(":modules:lib-common", ":modules:lib-script", ":modules:lib-tts")
   ```
3. **依赖**：在 `app/build.gradle.kts` 加入：
   ```kotlin
   implementation(project(":modules:lib-tts"))
   ```
4. **初始化**（App.onCreate 后）：
   ```kotlin
   // 1) 把宿主的 OkHttpClient 注入给移植层（复用阅读的连接池/超时策略）
   //    两种写法均可：直接注入 或 延迟注入（推荐，避免初始化顺序问题）
   com.github.jing332.compat.net.HostHttp.init(io.legado.app.help.http.okHttpClient)
   // 或： com.github.jing332.compat.net.HostHttp.init { io.legado.app.help.http.okHttpClient }
   // 2) 目录策略自动探测：优先 /storage/emulated/0/Download/chajian（需"所有文件访问"），
   //    未授权自动回退 filesDir/ttsrv；两条根读写兼容（TtsDirProvider）
   ```
   > 权限：数据根默认对齐补丁版 `Download/chajian/<pluginId>`。阅读已声明 `MANAGE_EXTERNAL_STORAGE`；
   > 用户未授权时自动走私有目录，不崩溃。

---

## 二、已做适配（B 档改动清单，对版依据见施工清单 §0.2）

| 项 | 处理 |
|---|---|
| `com.drake.net`（4 文件） | 替换为 `com.github.jing332.compat.net.HostHttp`（okhttp 直连；`cancelNetwork` 按 engineId tag 取消） |
| `io.github.oshai.kotlinlogging` | 替换为 `com.github.jing332.compat.log.KLog`（android.util.Log 垫片，支持 debug/trace/info/error/atXxx 全调用风格） |
| 数据目录（3 处同源） | 新增 `TtsDirProvider`；`JsExtensions.getFile` / `CompatScriptRuntime`(Environment) 接入；保留补丁版语义（`/` 开头路径直拼引擎根、父目录自动 mkdirs） |
| 整文件重写 | `JsNet.kt`、`GlobalHttp.kt`、`CompatScriptRuntime.kt`（对外 API 不变） |
| R8 keep | 照搬原规则：`@ScriptInterface` 方法 + `script.runtime/simple`、`compat.**`、`tts.**`、`org.mozilla.javascript`（见各模块 consumer-rules.pro） |
| Room | 实体仅保留注解，`compileOnly(room-runtime)`，不含 DAO（存储走宿主适配，阶段2） |
| Parcelize / Serialization | lib-common / lib-tts 已声明对应 kotlin 插件（`libs.plugins.kotlin.parcelize` / `libs.plugins.kotlin.serialization`） |
| Java/Kotlin 工具链 | 与阅读一致：Java 21 / compileSdk 37 / minSdk 26 |
| NativeBuffer 补丁类 | 保留（`org.mozilla.javascript.typedarrays.NativeBuffer`；已核实 Rhino 1.8.1 无此类，补丁扩展无冲突） |

## 三、未做 / 待办（阶段2+，见 `_stage2_not_ported/README.md`）

- **`TtsEngineContext` 管理 API 一套**（getAudioByTag 等；补丁版 APK 独有的增量，需从 APK 提炼 + 配置存储适配器）——阶段2
- `CachedEngineManager` / `SpeechServiceFactory` / 其余实体 / BGM 管道 / 本地 TTS 引擎 / 合成器全管道——阶段2 按需
- 插件导入/导出、声线列表、配置列表 UI——阶段2/4（本次只含引擎与运行时）

## 四、冒烟验证（对应施工清单 §4）

```kotlin
// 快速冒烟（suspend 环境；plugin.code 用现有插件 JSON 的 code 字段）
val plugin = Plugin(
    pluginId = "smoke.test", code = jsCode, userVars = mutableMapOf(), name = "冒烟"
)
val engine = TtsPluginEngineManager.get(context, plugin)   // 内部执行 eval()
val locales = engine.getLocales()                          // EditorJS.getLocales
val voices  = engine.getVoices(locales.keys.first())       // EditorJS.getVoices
val stream  = engine.getAudio("测试文本", locales.keys.first(), voices.first().id)
val head    = stream.readBytes().take(8)                   // 首8字节核对 mp3 帧头 fff3/fffb/ffe3 或 RIFF
```
- [ ] 编译通过（首次跑请留意下方注意事项）
- [ ] `getLocales/getVoices` 非空
- [ ] `getAudio` 返回流且帧头正确（否则按技能库 §5 决策树排查）
- [ ] 双插件（猫箱/剪映壳）复测

## 五、注意事项（首次编译重点）

1. **Rhino 版本**：与主工程 `modules/rhino` 保持一致（org.mozilla:rhino:1.8.1）。若主工程日后升级，同步升级。
2. **okhttp 5.5**：本模块声明 5.5.0；`WebSocketClient` 使用 okhttp 原生 WebSocket（无第三方依赖）。
3. **kotlin-result 已移除**：原第三方依赖（CI 无法解析）已替换为内置迷你实现（`com.github.jing332.script.result`），无需新增任何依赖。
4. **splitties appCtx**：依赖阅读现有 splitties 初始化（App 已初始化）；`RhinoClassShutter` 黑名单含 `splitties.init.AppCtxKt`（与原版一致，勿删）。
5. **命名空间**：三个模块 namespace 分别为 `com.github.jing332.common/script/tts`，与 `com.script`（书源引擎）互不冲突。
6. **首次编译预警**：本树在沙箱内无法执行 Android 编译，已做静态自检（引用完整性=0 缺失）；首次编译如有个别 API 差异（okhttp5 或 Kotlin 版本涟漪），改动面已最小化，逐条修即可。
