package io.legado.app.ui.ttssrv

import android.app.Application
import android.media.MediaPlayer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import io.legado.app.R
import io.legado.app.data.repository.EngineOption
import io.legado.app.data.repository.EntryRow
import io.legado.app.data.repository.GroupRow
import io.legado.app.data.repository.LocaleOption
import io.legado.app.data.repository.PluginRow
import io.legado.app.data.repository.TtsServerCenterRepository
import io.legado.app.data.repository.VarField
import io.legado.app.data.repository.VoiceOption
import io.legado.app.ui.theme.adaptiveContentPadding
import io.legado.app.ui.widget.components.AppFloatingActionButton
import io.legado.app.ui.widget.components.AppScaffold
import io.legado.app.ui.widget.components.AppTextField
import io.legado.app.ui.widget.components.SectionTitle
import io.legado.app.ui.widget.components.SplicedColumnGroup
import io.legado.app.ui.widget.components.alert.AppAlertDialog
import io.legado.app.ui.widget.components.filePicker.FilePickerSheet
import io.legado.app.ui.widget.components.log.LogDetailSheet
import io.legado.app.ui.widget.components.modalBottomSheet.AppModalBottomSheet
import io.legado.app.ui.widget.components.settingItem.TinyClickableSettingItem
import io.legado.app.ui.widget.components.tabRow.AppTabRow
import io.legado.app.ui.widget.components.topbar.GlassMediumFlexibleTopAppBar
import io.legado.app.ui.widget.components.topbar.GlassTopAppBarDefaults
import io.legado.app.ui.widget.components.topbar.TopBarActionButton
import io.legado.app.ui.widget.components.topbar.TopBarNavigationButton
import io.legado.app.utils.toastOnUi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * TTS-Server 管理中心（UI-2A 深度复刻版）：
 *  - 顶栏：返回 / 当前引擎(副标题) / 切换引擎 / 刷新
 *  - 音色插件：分组折叠、行内开关、长按多选（全选/导出/启停/删除）、⋮操作（试听[选语言→音色]/
 *    编辑变量/原始JSON/导出/上移/下移/置顶/置底/删除）
 *  - 配置列表：分组折叠 + 二级分类折叠、搜索、长按多选（全选/导出/删除）、
 *    组⋮（重命名/导出组/新建到此组/删除组）、新建条目（选插件→语言→音色→标签表单）、
 *    编辑条目（名称/标签/分类/音频参数）、试听、重命名、删除
 */
@Composable
fun TtsServerCenterRouteScreen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    TtsServerCenterScreen(
        app = context.applicationContext as Application,
        onBack = onBackClick,
    )
}

private sealed interface CenterSheet {
    data class PluginActions(val plugin: PluginRow) : CenterSheet
    data class EntryActions(val entry: EntryRow) : CenterSheet
    data class GroupActions(val name: String) : CenterSheet
    data object PickPluginForNew : CenterSheet
    data object ManualImport : CenterSheet
}

private sealed interface PickerPurpose {
    data object Audition : PickerPurpose
    data object NewEntry : PickerPurpose
}

private data class PickerTarget(
    val pluginId: String,
    val pluginName: String,
    val purpose: PickerPurpose,
)

private data class VoicePrefill(
    val pluginId: String,
    val pluginName: String,
    val locale: String,
    val voice: String,
    val voiceName: String,
)

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun TtsServerCenterScreen(app: Application, onBack: () -> Unit) {
    val context = LocalContext.current
    val repo = remember(app) { TtsServerCenterRepository(app) }
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableStateOf(0) }
    var plugins by remember { mutableStateOf<List<PluginRow>>(emptyList()) }
    var groups by remember { mutableStateOf<List<GroupRow>>(emptyList()) }
    var engineValue by remember { mutableStateOf<String?>(null) }
    var engineLoaded by remember { mutableStateOf(false) }
    var engineOptions by remember { mutableStateOf<List<EngineOption>>(emptyList()) }

    var query by remember { mutableStateOf("") }
    val collapsedPluginGroups = remember { mutableStateMapOf<String, Boolean>() }
    val collapsedGroups = remember { mutableStateMapOf<String, Boolean>() }
    val collapsedCats = remember { mutableStateMapOf<String, Boolean>() }

    var pluginSelMode by remember { mutableStateOf(false) }
    var selPlugins by remember { mutableStateOf(setOf<String>()) }
    var entrySelMode by remember { mutableStateOf(false) }
    var selEntries by remember { mutableStateOf(setOf<String>()) }

    var sheet by remember { mutableStateOf<CenterSheet?>(null) }
    var showImportPicker by remember { mutableStateOf(false) }
    var importKind by remember { mutableStateOf(0) } // 0=插件 1=配置列表
    var detailTitle by remember { mutableStateOf("") }
    var detailText by remember { mutableStateOf<String?>(null) }

    var showEngineSheet by remember { mutableStateOf(false) }
    var pendingEngine by remember { mutableStateOf<EngineOption?>(null) }
    var showScopeDialog by remember { mutableStateOf(false) }

    var showDeletePlugin by remember { mutableStateOf<PluginRow?>(null) }
    var showDeleteEntry by remember { mutableStateOf<EntryRow?>(null) }
    var renameTarget by remember { mutableStateOf<EntryRow?>(null) }
    var confirmDeleteGroup by remember { mutableStateOf<String?>(null) }
    var confirmDeleteSelEntries by remember { mutableStateOf(false) }

    var importText by remember { mutableStateOf("") }
    var renameText by remember { mutableStateOf("") }
    var varsEditorPlugin by remember { mutableStateOf<PluginRow?>(null) }
    var varFields by remember { mutableStateOf<List<VarField>>(emptyList()) }
    val varValues = remember { mutableStateMapOf<String, String>() }

    // 声线选择 / 新建 / 编辑
    var pickerTarget by remember { mutableStateOf<PickerTarget?>(null) }
    var pickerLocales by remember { mutableStateOf<List<LocaleOption>>(emptyList()) }
    var pickerVoices by remember { mutableStateOf<List<VoiceOption>>(emptyList()) }
    var pickerLocale by remember { mutableStateOf<LocaleOption?>(null) }
    var pickerBusy by remember { mutableStateOf(false) }
    var newEntryGroupDefault by remember { mutableStateOf<String?>(null) }
    var newEntryPrefill by remember { mutableStateOf<VoicePrefill?>(null) }
    var neGroup by remember { mutableStateOf("") }
    var neName by remember { mutableStateOf("") }
    var neTag by remember { mutableStateOf("") }
    var neRuleId by remember { mutableStateOf("mingwuyan") }
    var neTagName by remember { mutableStateOf("") }
    var neCategory by remember { mutableStateOf("自建") }
    var editTarget by remember { mutableStateOf<EntryRow?>(null) }
    var edName by remember { mutableStateOf("") }
    var edTag by remember { mutableStateOf("") }
    var edRuleId by remember { mutableStateOf("") }
    var edTagName by remember { mutableStateOf("") }
    var edCategory by remember { mutableStateOf("") }
    var edSpeed by remember { mutableStateOf("") }
    var edVolume by remember { mutableStateOf("") }
    var edPitch by remember { mutableStateOf("") }
    var renameGroupTarget by remember { mutableStateOf<String?>(null) }
    var renameGroupText by remember { mutableStateOf("") }

    val player = remember { MediaPlayer() }
    DisposableEffect(player) {
        onDispose { runCatching { player.release() } }
    }

    fun reload() {
        scope.launch {
            plugins = repo.loadPlugins()
            groups = repo.loadGroups()
            engineOptions = repo.loadEngineOptions()
            engineValue = repo.currentEngineValue()
            engineLoaded = true
        }
    }

    fun entryKeyOf(e: EntryRow): String = "${e.tagRuleId}|${e.tag}"

    fun matchedEntries(): List<EntryRow> {
        val all = groups.flatMap { it.entries }
        if (query.isBlank()) return all
        return all.filter {
            it.displayName.contains(query, true) || it.tag.contains(query, true) ||
                    it.voice.contains(query, true) || it.pluginId.contains(query, true)
        }
    }

    fun play(path: String) {
        runCatching {
            player.reset()
            player.setDataSource(path)
            player.prepare()
            player.start()
        }.onFailure {
            context.toastOnUi("播放失败：${it.message.orEmpty()}")
        }
    }

    LaunchedEffect(Unit) { reload() }

    LaunchedEffect(pickerTarget) {
        val t = pickerTarget ?: return@LaunchedEffect
        pickerBusy = true
        pickerLocales = repo.loadLocales(t.pluginId)
        pickerVoices = emptyList()
        pickerLocale = null
        pickerBusy = false
        if (pickerLocales.isEmpty()) {
            detailTitle = "读取语言列表失败"
            detailText = "插件「${t.pluginName}」未返回语言列表（检查插件是否启用 / 是否被沙箱拦截）。"
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val text = runCatching {
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)
                            ?.bufferedReader()?.use { it.readText() }
                    }
                }.getOrNull()
                if (text.isNullOrBlank()) {
                    context.toastOnUi("读取文件为空或失败")
                } else {
                    val msg =
                        if (importKind == 0) repo.importPlugins(text) else repo.importVoices(text)
                    context.toastOnUi(msg)
                    reload()
                }
            }
        }
    }

    val scrollBehavior = GlassTopAppBarDefaults.defaultScrollBehavior()
    val engineSubtitle =
        if (!engineLoaded) "当前引擎：…" else "当前引擎：${repo.engineLabel(engineValue)}"

    AppScaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            GlassMediumFlexibleTopAppBar(
                title = stringResource(R.string.read_aloud_engines_and_voices),
                subtitle = engineSubtitle,
                scrollBehavior = scrollBehavior,
                navigationIcon = { TopBarNavigationButton(onClick = onBack) },
                actions = {
                    TopBarActionButton(
                        onClick = { showEngineSheet = true },
                        imageVector = Icons.Default.SwapHoriz,
                        contentDescription = "切换朗读引擎",
                    )
                    TopBarActionButton(
                        onClick = { reload() },
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "刷新",
                    )
                },
                bottomContent = {
                    AppTabRow(
                        tabTitles = listOf("音色插件", "配置列表"),
                        selectedTabIndex = selectedTab,
                        onTabSelected = { selectedTab = it },
                        isScrollable = false,
                    )
                },
            )
        },
        floatingActionButton = {
            if (selectedTab == 1 && !entrySelMode) {
                AppFloatingActionButton(
                    onClick = {
                        newEntryGroupDefault = null
                        sheet = CenterSheet.PickPluginForNew
                    },
                    icon = Icons.Default.Add,
                    tooltipText = "新建条目",
                )
            }
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = adaptiveContentPadding(
                top = padding.calculateTopPadding() + 8.dp,
                bottom = padding.calculateBottomPadding() + 96.dp,
            ),
        ) {
            if (selectedTab == 0) {
                // ================= 音色插件页 =================
                if (pluginSelMode) {
                    item {
                        SplicedColumnGroup(title = "已选 ${selPlugins.size} 个插件") {
                            TinyClickableSettingItem(
                                title = "全选",
                                onClick = { selPlugins = plugins.map { it.pluginId }.toSet() },
                            )
                            TinyClickableSettingItem(
                                title = "导出所选",
                                onClick = {
                                    scope.launch {
                                        detailTitle = "导出完成（所选插件）"
                                        detailText = repo.exportPluginsByIds(selPlugins)
                                    }
                                },
                            )
                            TinyClickableSettingItem(
                                title = "启用所选",
                                onClick = {
                                    scope.launch {
                                        repo.setPluginsEnabled(selPlugins, true)
                                        context.toastOnUi("已启用")
                                        reload()
                                    }
                                },
                            )
                            TinyClickableSettingItem(
                                title = "停用所选",
                                onClick = {
                                    scope.launch {
                                        repo.setPluginsEnabled(selPlugins, false)
                                        context.toastOnUi("已停用")
                                        reload()
                                    }
                                },
                            )
                            TinyClickableSettingItem(
                                title = "删除所选",
                                onClick = {
                                    scope.launch {
                                        repo.deletePlugins(selPlugins)
                                        context.toastOnUi("已删除")
                                        pluginSelMode = false
                                        selPlugins = emptySet()
                                        reload()
                                    }
                                },
                            )
                            TinyClickableSettingItem(
                                title = "退出多选",
                                onClick = {
                                    pluginSelMode = false
                                    selPlugins = emptySet()
                                },
                            )
                        }
                    }
                }
                item {
                    SplicedColumnGroup(title = "插件操作") {
                        TinyClickableSettingItem(
                            title = "导入插件…",
                            description = "从文件选择 / 手动粘贴 JSON",
                            imageVector = Icons.Default.Upload,
                            onClick = {
                                importKind = 0
                                showImportPicker = true
                            },
                        )
                        TinyClickableSettingItem(
                            title = "导出全部插件",
                            description = "输出到 Download/chajian/_exports",
                            imageVector = Icons.Default.Download,
                            onClick = {
                                scope.launch {
                                    detailTitle = "导出完成（插件）"
                                    detailText = repo.exportPlugins()
                                }
                            },
                        )
                        TinyClickableSettingItem(
                            title = "多选模式",
                            description = "长按列表项也可进入",
                            onClick = {
                                pluginSelMode = true
                                selPlugins = emptySet()
                            },
                        )
                    }
                }
                if (plugins.isEmpty()) {
                    item {
                        SplicedColumnGroup(title = "音色插件") {
                            TinyClickableSettingItem(
                                title = "暂无插件",
                                description = "先用上方导入插件 JSON",
                                onClick = {},
                            )
                        }
                    }
                }
                val groupedPlugins = plugins.groupBy { it.groupName.ifBlank { "未分组" } }
                groupedPlugins.forEach { (gName, list) ->
                    item(key = "pg_$gName") {
                        FolderRow(
                            title = "$gName（${list.size}）",
                            collapsed = collapsedPluginGroups[gName] == true,
                            onClick = {
                                collapsedPluginGroups[gName] =
                                    !(collapsedPluginGroups[gName] ?: false)
                            },
                        )
                    }
                    if (collapsedPluginGroups[gName] != true) {
                        items(list) { p ->
                            val selected = p.pluginId in selPlugins
                            TinyClickableSettingItem(
                                title = (if (pluginSelMode) {
                                    if (selected) "☑ " else "☐ "
                                } else {
                                    if (p.enabled) "🟢 " else "⚪️ "
                                }) + p.name,
                                description = "${p.pluginId} · v${p.version} · ${p.author}",
                                onClick = {
                                    if (pluginSelMode) {
                                        selPlugins = if (selected) {
                                            selPlugins - p.pluginId
                                        } else {
                                            selPlugins + p.pluginId
                                        }
                                    } else {
                                        sheet = CenterSheet.PluginActions(p)
                                    }
                                },
                                onLongClick = {
                                    if (!pluginSelMode) {
                                        pluginSelMode = true
                                        selPlugins = setOf(p.pluginId)
                                    }
                                },
                                trailingContent = {
                                    if (!pluginSelMode) {
                                        Switch(
                                            checked = p.enabled,
                                            onCheckedChange = {
                                                scope.launch {
                                                    repo.setPluginEnabled(p.pluginId, !p.enabled)
                                                    reload()
                                                }
                                            },
                                        )
                                    }
                                },
                            )
                        }
                    }
                }
            } else {
                // ================= 配置列表页 =================
                if (entrySelMode) {
                    item {
                        SplicedColumnGroup(title = "已选 ${selEntries.size} 条") {
                            TinyClickableSettingItem(
                                title = "全选（当前筛选范围）",
                                onClick = {
                                    selEntries = matchedEntries().map { entryKeyOf(it) }.toSet()
                                },
                            )
                            TinyClickableSettingItem(
                                title = "导出所选",
                                onClick = {
                                    scope.launch {
                                        detailTitle = "导出完成（所选条目）"
                                        detailText = repo.exportEntries(selEntries)
                                    }
                                },
                            )
                            TinyClickableSettingItem(
                                title = "删除所选",
                                onClick = { confirmDeleteSelEntries = true },
                            )
                            TinyClickableSettingItem(
                                title = "退出多选",
                                onClick = {
                                    entrySelMode = false
                                    selEntries = emptySet()
                                },
                            )
                        }
                    }
                }
                item {
                    SplicedColumnGroup(title = "列表操作") {
                        TinyClickableSettingItem(
                            title = "导入配置列表…",
                            description = "原生 [{group,list}] 或合集 JSON",
                            imageVector = Icons.Default.Upload,
                            onClick = {
                                importKind = 1
                                showImportPicker = true
                            },
                        )
                        TinyClickableSettingItem(
                            title = "导出配置列表",
                            description = "输出到 Download/chajian/_exports",
                            imageVector = Icons.Default.Download,
                            onClick = {
                                scope.launch {
                                    detailTitle = "导出完成（配置列表）"
                                    detailText = repo.exportVoices()
                                }
                            },
                        )
                        TinyClickableSettingItem(
                            title = "新建条目…",
                            description = "选择插件 → 语言 → 音色",
                            imageVector = Icons.Default.Add,
                            onClick = {
                                newEntryGroupDefault = null
                                sheet = CenterSheet.PickPluginForNew
                            },
                        )
                        TinyClickableSettingItem(
                            title = "多选模式",
                            description = "长按列表项也可进入",
                            onClick = {
                                entrySelMode = true
                                selEntries = emptySet()
                            },
                        )
                    }
                }
                item {
                    AppTextField(
                        value = query,
                        onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth(),
                        label = "搜索：名称 / 标签 / 音色 / 插件",
                        singleLine = true,
                    )
                }
                if (groups.isEmpty()) {
                    item {
                        TinyClickableSettingItem(
                            title = "暂无配置列表",
                            description = "用上方导入，或点右下角 + 新建条目",
                            onClick = {},
                        )
                    }
                }
                if (query.isNotBlank()) {
                    val filtered = matchedEntries()
                    item { SectionTitle("搜索结果（${filtered.size}）") }
                    items(filtered) { e ->
                        val selected = entryKeyOf(e) in selEntries
                        TinyClickableSettingItem(
                            title = (if (entrySelMode) {
                                if (selected) "☑ " else "☐ "
                            } else "") + "[${e.tag}] ${e.displayName}",
                            description = "${e.voice} · ${e.pluginId}",
                            onClick = {
                                if (entrySelMode) {
                                    val k = entryKeyOf(e)
                                    selEntries =
                                        if (k in selEntries) selEntries - k else selEntries + k
                                } else {
                                    sheet = CenterSheet.EntryActions(e)
                                }
                            },
                            onLongClick = {
                                if (!entrySelMode) {
                                    entrySelMode = true
                                    selEntries = setOf(entryKeyOf(e))
                                }
                            },
                        )
                    }
                } else {
                    groups.forEach { g ->
                        item(key = "vg_${g.name}") {
                            FolderRow(
                                title = "${g.name}（${g.entries.size}）",
                                collapsed = collapsedGroups[g.name] == true,
                                trailing = {
                                    IconButton(onClick = {
                                        sheet = CenterSheet.GroupActions(g.name)
                                    }) {
                                        Icon(Icons.Default.MoreVert, contentDescription = "分组菜单")
                                    }
                                },
                                onClick = {
                                    collapsedGroups[g.name] =
                                        !(collapsedGroups[g.name] ?: false)
                                },
                            )
                        }
                        if (collapsedGroups[g.name] != true) {
                            val byCat = g.entries.groupBy { it.categoryPath.ifBlank { "未分类" } }
                            byCat.forEach { (cat, list) ->
                                val catKey = "${g.name}|$cat"
                                item(key = "vc_$catKey") {
                                    FolderRow(
                                        title = "$cat（${list.size}）",
                                        collapsed = collapsedCats[catKey] == true,
                                        indent = true,
                                        onClick = {
                                            collapsedCats[catKey] =
                                                !(collapsedCats[catKey] ?: false)
                                        },
                                    )
                                }
                                if (collapsedCats[catKey] != true) {
                                    items(list) { e ->
                                        val selected = entryKeyOf(e) in selEntries
                                        TinyClickableSettingItem(
                                            title = (if (entrySelMode) {
                                                if (selected) "☑ " else "☐ "
                                            } else "") + "[${e.tag}] ${e.displayName}",
                                            description = "${e.voice} · ${e.pluginId}",
                                            onClick = {
                                                if (entrySelMode) {
                                                    val k = entryKeyOf(e)
                                                    selEntries = if (k in selEntries) {
                                                        selEntries - k
                                                    } else {
                                                        selEntries + k
                                                    }
                                                } else {
                                                    sheet = CenterSheet.EntryActions(e)
                                                }
                                            },
                                            onLongClick = {
                                                if (!entrySelMode) {
                                                    entrySelMode = true
                                                    selEntries = setOf(entryKeyOf(e))
                                                }
                                            },
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // ---------------- 导入选择 ----------------
    FilePickerSheet(
        show = showImportPicker,
        onDismissRequest = { showImportPicker = false },
        title = if (importKind == 0) "导入插件" else "导入配置列表",
        onSelectSysFile = { types ->
            showImportPicker = false
            importLauncher.launch(types)
        },
        onManualInput = {
            showImportPicker = false
            sheet = CenterSheet.ManualImport
        },
        allowExtensions = arrayOf("json", "txt"),
    )

    // ---------------- 手动粘贴 ----------------
    AppModalBottomSheet(
        show = sheet is CenterSheet.ManualImport,
        onDismissRequest = { sheet = null },
        title = if (importKind == 0) "粘贴插件 JSON" else "粘贴配置列表 JSON",
    ) {
        AppTextField(
            value = importText,
            onValueChange = { importText = it },
            modifier = Modifier.fillMaxWidth(),
            label = "粘贴 JSON 内容",
            minLines = 6,
            maxLines = 12,
        )
        Spacer(modifier = Modifier.height(12.dp))
        TinyClickableSettingItem(
            title = "从剪贴板粘贴",
            onClick = {
                val cm = context.getSystemService(android.content.ClipboardManager::class.java)
                val t = cm?.primaryClip?.takeIf { it.itemCount > 0 }
                    ?.getItemAt(0)?.coerceToText(context)?.toString()
                if (t.isNullOrBlank()) {
                    context.toastOnUi("剪贴板为空")
                } else {
                    importText = t
                    context.toastOnUi("已粘贴 ${t.length} 字符")
                }
            },
        )
        TinyClickableSettingItem(
            title = "确认导入",
            onClick = {
                val text = importText
                sheet = null
                importText = ""
                if (text.isBlank()) {
                    context.toastOnUi("内容为空")
                } else {
                    scope.launch {
                        val msg =
                            if (importKind == 0) repo.importPlugins(text) else repo.importVoices(text)
                        context.toastOnUi(msg)
                        reload()
                    }
                }
            },
        )
        TinyClickableSettingItem(title = "取消", onClick = { sheet = null })
    }

    // ---------------- 插件操作 ----------------
    AppModalBottomSheet(
        show = sheet is CenterSheet.PluginActions,
        onDismissRequest = { sheet = null },
        title = (sheet as? CenterSheet.PluginActions)?.plugin?.name ?: "插件操作",
    ) {
        val p = (sheet as? CenterSheet.PluginActions)?.plugin
        if (p != null) {
            TinyClickableSettingItem(
                title = "试听（选语言 → 音色）",
                description = "直接合成一段试听并播放",
                imageVector = Icons.Default.PlayArrow,
                onClick = {
                    sheet = null
                    pickerTarget = PickerTarget(p.pluginId, p.name, PickerPurpose.Audition)
                },
            )
            TinyClickableSettingItem(
                title = if (p.enabled) "停用插件" else "启用插件",
                onClick = {
                    sheet = null
                    scope.launch {
                        repo.setPluginEnabled(p.pluginId, !p.enabled)
                        context.toastOnUi(if (p.enabled) "已停用" else "已启用")
                        reload()
                    }
                },
            )
            TinyClickableSettingItem(
                title = "编辑变量（如 APIKEY 等）",
                description = "按插件定义的表单填写并保存",
                onClick = {
                    sheet = null
                    scope.launch {
                        val fields = repo.loadVarFields(p.pluginId)
                        varValues.clear()
                        fields.forEach { varValues[it.key] = it.value }
                        varFields = fields
                        varsEditorPlugin = p
                    }
                },
            )
            TinyClickableSettingItem(
                title = "查看原始 JSON（defVars / userVars）",
                onClick = {
                    sheet = null
                    scope.launch {
                        detailTitle = "插件变量（原始）"
                        detailText = repo.pluginVarsText(p.pluginId)
                    }
                },
            )
            TinyClickableSettingItem(
                title = "导出此插件",
                onClick = {
                    sheet = null
                    scope.launch {
                        detailTitle = "导出完成"
                        detailText = repo.exportPlugin(p.pluginId)
                    }
                },
            )
            TinyClickableSettingItem(
                title = "上移",
                onClick = {
                    sheet = null
                    scope.launch { repo.movePlugin(p.pluginId, "up"); reload() }
                },
            )
            TinyClickableSettingItem(
                title = "下移",
                onClick = {
                    sheet = null
                    scope.launch { repo.movePlugin(p.pluginId, "down"); reload() }
                },
            )
            TinyClickableSettingItem(
                title = "置顶",
                onClick = {
                    sheet = null
                    scope.launch { repo.movePlugin(p.pluginId, "top"); reload() }
                },
            )
            TinyClickableSettingItem(
                title = "置底",
                onClick = {
                    sheet = null
                    scope.launch { repo.movePlugin(p.pluginId, "bottom"); reload() }
                },
            )
            TinyClickableSettingItem(
                title = "删除插件",
                onClick = {
                    sheet = null
                    showDeletePlugin = p
                },
            )
        }
    }

    // ---------------- 分组操作 ----------------
    AppModalBottomSheet(
        show = sheet is CenterSheet.GroupActions,
        onDismissRequest = { sheet = null },
        title = (sheet as? CenterSheet.GroupActions)?.name ?: "分组操作",
    ) {
        val gName = (sheet as? CenterSheet.GroupActions)?.name
        if (gName != null) {
            TinyClickableSettingItem(
                title = "重命名分组",
                onClick = {
                    renameGroupText = gName
                    sheet = null
                    renameGroupTarget = gName
                },
            )
            TinyClickableSettingItem(
                title = "导出该分组",
                onClick = {
                    sheet = null
                    scope.launch {
                        detailTitle = "导出完成（分组）"
                        detailText = repo.exportGroup(gName)
                    }
                },
            )
            TinyClickableSettingItem(
                title = "在此分组新建条目",
                description = "选择插件 → 语言 → 音色",
                onClick = {
                    sheet = null
                    newEntryGroupDefault = gName
                    sheet = CenterSheet.PickPluginForNew
                },
            )
            TinyClickableSettingItem(
                title = "删除该分组（含所有条目）",
                onClick = {
                    sheet = null
                    confirmDeleteGroup = gName
                },
            )
        }
    }

    // ---------------- 选择插件（新建条目） ----------------
    AppModalBottomSheet(
        show = sheet is CenterSheet.PickPluginForNew,
        onDismissRequest = { sheet = null },
        title = "选择插件（新条目）",
    ) {
        if (plugins.isEmpty()) {
            TinyClickableSettingItem(title = "暂无可用插件", onClick = {})
        }
        plugins.forEach { p ->
            TinyClickableSettingItem(
                title = p.name,
                description = "${p.pluginId}${if (p.enabled) "" else "（未启用）"}",
                onClick = {
                    sheet = null
                    pickerTarget = PickerTarget(p.pluginId, p.name, PickerPurpose.NewEntry)
                },
            )
        }
    }

    // ---------------- 声线选择（试听 / 新建共用） ----------------
    AppModalBottomSheet(
        show = pickerTarget != null,
        onDismissRequest = { pickerTarget = null },
        title = pickerTarget?.let {
            (if (it.purpose == PickerPurpose.Audition) "试听" else "新建条目") + "：" + it.pluginName
        } ?: "",
    ) {
        val t = pickerTarget
        if (t != null) {
            if (pickerBusy) {
                TinyClickableSettingItem(title = "加载中…", onClick = {})
            } else if (pickerLocale == null) {
                if (pickerLocales.isEmpty()) {
                    TinyClickableSettingItem(title = "无可用语言", onClick = {})
                }
                pickerLocales.forEach { loc ->
                    TinyClickableSettingItem(
                        title = loc.name.ifBlank { loc.id },
                        description = loc.id,
                        onClick = {
                            scope.launch {
                                pickerBusy = true
                                pickerVoices = repo.loadVoices(t.pluginId, loc.id)
                                pickerLocale = loc
                                pickerBusy = false
                                if (pickerVoices.isEmpty()) {
                                    context.toastOnUi("该语言下未读取到音色")
                                }
                            }
                        },
                    )
                }
            } else {
                TinyClickableSettingItem(
                    title = "← 返回语言列表",
                    onClick = {
                        pickerLocale = null
                        pickerVoices = emptyList()
                    },
                )
                if (pickerVoices.isEmpty()) {
                    TinyClickableSettingItem(title = "无可用音色", onClick = {})
                }
                pickerVoices.forEach { v ->
                    TinyClickableSettingItem(
                        title = v.name.ifBlank { v.id },
                        description = v.id,
                        onClick = {
                            val loc = pickerLocale ?: return@TinyClickableSettingItem
                            when (t.purpose) {
                                PickerPurpose.Audition -> {
                                    pickerTarget = null
                                    scope.launch {
                                        context.toastOnUi("正在合成…")
                                        val r = repo.auditionDirect(
                                            t.pluginId, loc.id, v.id, "你好，这是插件试听。"
                                        )
                                        if (r.ok && r.path != null) {
                                            play(r.path)
                                            context.toastOnUi("播放中")
                                        } else {
                                            detailTitle = "试听失败（诊断报告）"
                                            detailText = r.message
                                        }
                                    }
                                }

                                PickerPurpose.NewEntry -> {
                                    pickerTarget = null
                                    neGroup = newEntryGroupDefault ?: groups.firstOrNull()?.name
                                    ?: "自建"
                                    neName = v.name.ifBlank { v.id }
                                    neTag = ""
                                    neRuleId = "mingwuyan"
                                    neTagName = ""
                                    neCategory = "自建"
                                    newEntryPrefill = VoicePrefill(
                                        pluginId = t.pluginId,
                                        pluginName = t.pluginName,
                                        locale = loc.id,
                                        voice = v.id,
                                        voiceName = v.name.ifBlank { v.id },
                                    )
                                }
                            }
                        },
                    )
                }
            }
        }
    }

    // ---------------- 新建条目表单 ----------------
    AppModalBottomSheet(
        show = newEntryPrefill != null,
        onDismissRequest = { newEntryPrefill = null },
        title = "新建条目（${newEntryPrefill?.voiceName.orEmpty()}）",
    ) {
        val pf = newEntryPrefill
        if (pf != null) {
            TinyClickableSettingItem(
                title = "声线：${pf.voiceName}（${pf.voice}）",
                description = "插件：${pf.pluginName} · 语言：${pf.locale}",
                onClick = {},
            )
            SheetField("分组", neGroup) { neGroup = it }
            SheetField("显示名", neName) { neName = it }
            SheetField("标签（tag，如 女童01）", neTag) { neTag = it }
            SheetField("标签规则（tagRuleId）", neRuleId) { neRuleId = it }
            SheetField("标签显示名（tagName，可空）", neTagName) { neTagName = it }
            SheetField("分类路径（categoryPath）", neCategory) { neCategory = it }
            TinyClickableSettingItem(
                title = "保存新条目",
                onClick = {
                    val p = newEntryPrefill ?: return@TinyClickableSettingItem
                    if (neTag.isBlank()) {
                        context.toastOnUi("标签（tag）不能为空")
                        return@TinyClickableSettingItem
                    }
                    newEntryPrefill = null
                    scope.launch {
                        val ok = repo.appendVoiceEntry(
                            groupName = neGroup.ifBlank { "自建" },
                            displayName = neName.ifBlank { p.voiceName },
                            tag = neTag.trim(),
                            tagRuleId = neRuleId.ifBlank { "mingwuyan" },
                            tagName = neTagName,
                            categoryPath = neCategory.ifBlank { "自建" },
                            pluginId = p.pluginId,
                            locale = p.locale,
                            voice = p.voice,
                        )
                        context.toastOnUi(if (ok) "已保存新条目" else "保存失败")
                        reload()
                    }
                },
            )
        }
    }

    // ---------------- 编辑条目表单 ----------------
    AppModalBottomSheet(
        show = editTarget != null,
        onDismissRequest = { editTarget = null },
        title = "编辑条目：${editTarget?.displayName.orEmpty()}",
    ) {
        val t = editTarget
        if (t != null) {
            SheetField("显示名", edName) { edName = it }
            SheetField("标签（tag）", edTag) { edTag = it }
            SheetField("标签规则（tagRuleId）", edRuleId) { edRuleId = it }
            SheetField("标签显示名（tagName）", edTagName) { edTagName = it }
            SheetField("分类路径（categoryPath）", edCategory) { edCategory = it }
            SheetField("语速（0=跟随，1.0=原速）", edSpeed) { edSpeed = it }
            SheetField("音量（0=跟随，1.0=原量）", edVolume) { edVolume = it }
            SheetField("音高（0=跟随，1.0=原调）", edPitch) { edPitch = it }
            TinyClickableSettingItem(
                title = "保存修改",
                onClick = {
                    if (edTag.isBlank() || edRuleId.isBlank()) {
                        context.toastOnUi("标签 / 标签规则不能为空")
                        return@TinyClickableSettingItem
                    }
                    editTarget = null
                    scope.launch {
                        val ok = repo.updateVoiceEntry(
                            oldRuleId = t.tagRuleId,
                            oldTag = t.tag,
                            newName = edName,
                            newTag = edTag.trim(),
                            newRuleId = edRuleId.trim(),
                            newTagName = edTagName,
                            newCategoryPath = edCategory,
                            speed = edSpeed.toFloatOrNull() ?: 0f,
                            volume = edVolume.toFloatOrNull() ?: 0f,
                            pitch = edPitch.toFloatOrNull() ?: 0f,
                        )
                        context.toastOnUi(if (ok) "已保存" else "保存失败")
                        reload()
                    }
                },
            )
        }
    }

    // ---------------- 变量编辑 ----------------
    AppModalBottomSheet(
        show = varsEditorPlugin != null,
        onDismissRequest = { varsEditorPlugin = null },
        title = "编辑变量：${varsEditorPlugin?.name.orEmpty()}",
    ) {
        if (varFields.isEmpty()) {
            TinyClickableSettingItem(title = "此插件未定义变量", onClick = {})
        }
        varFields.forEach { f ->
            AppTextField(
                value = varValues[f.key] ?: "",
                onValueChange = { varValues[f.key] = it },
                modifier = Modifier.fillMaxWidth(),
                label = if (f.description.isNotBlank()) {
                    "${f.label}（${f.description}）"
                } else {
                    f.label
                },
                singleLine = true,
            )
            Spacer(modifier = Modifier.height(8.dp))
        }
        Spacer(modifier = Modifier.height(4.dp))
        TinyClickableSettingItem(
            title = "保存变量（保存后引擎缓存自动刷新）",
            onClick = {
                val p = varsEditorPlugin ?: return@TinyClickableSettingItem
                varsEditorPlugin = null
                scope.launch {
                    val ok = repo.savePluginUserVars(p.pluginId, varValues.toMap())
                    context.toastOnUi(if (ok) "变量已保存" else "保存失败")
                    reload()
                }
            },
        )
    }

    // ---------------- 声线条目操作 ----------------
    AppModalBottomSheet(
        show = sheet is CenterSheet.EntryActions,
        onDismissRequest = { sheet = null },
        title = (sheet as? CenterSheet.EntryActions)?.entry?.let {
            "[${it.tag}] ${it.displayName}"
        } ?: "声线条目",
    ) {
        val e = (sheet as? CenterSheet.EntryActions)?.entry
        if (e != null) {
            TinyClickableSettingItem(
                title = "试听（合成并播放）",
                description = "走 内置引擎 → 标签 ${e.tag}",
                imageVector = Icons.Default.PlayArrow,
                onClick = {
                    sheet = null
                    scope.launch {
                        context.toastOnUi("正在合成…")
                        val r = repo.auditionDetailed(
                            e.tagRuleId, e.tag, "你好，这里是移植层试听。"
                        )
                        if (r.ok && r.path != null) {
                            play(r.path)
                            context.toastOnUi("播放中：${r.path.substringAfterLast('/')}")
                        } else {
                            detailTitle = "试听失败（诊断报告）"
                            detailText = r.message
                            context.toastOnUi("合成失败（详情已弹出）")
                        }
                    }
                },
            )
            TinyClickableSettingItem(
                title = "编辑条目（名称/标签/分类/音频参数）",
                onClick = {
                    sheet = null
                    edName = e.displayName
                    edTag = e.tag
                    edRuleId = e.tagRuleId
                    edTagName = e.tagName
                    edCategory = e.categoryPath
                    edSpeed = if (e.speed > 0f) e.speed.toString() else "0"
                    edVolume = if (e.volume > 0f) e.volume.toString() else "0"
                    edPitch = if (e.pitch > 0f) e.pitch.toString() else "0"
                    editTarget = e
                },
            )
            TinyClickableSettingItem(
                title = "重命名显示名",
                description = "当前：${e.displayName}",
                onClick = {
                    renameText = e.displayName
                    sheet = null
                    renameTarget = e
                },
            )
            TinyClickableSettingItem(
                title = "删除此声线配置",
                onClick = {
                    sheet = null
                    showDeleteEntry = e
                },
            )
        }
    }

    // ---------------- 引擎切换 ----------------
    AppModalBottomSheet(
        show = showEngineSheet,
        onDismissRequest = { showEngineSheet = false },
        title = "切换朗读引擎",
    ) {
        engineOptions.forEach { opt ->
            val current = (opt.value == null && engineValue.isNullOrBlank()) ||
                    (opt.value != null && opt.value == engineValue)
            TinyClickableSettingItem(
                title = (if (current) "✓ " else "") + opt.label,
                onClick = {
                    showEngineSheet = false
                    pendingEngine = opt
                    showScopeDialog = true
                },
            )
        }
    }

    AppAlertDialog(
        show = showScopeDialog,
        onDismissRequest = {
            showScopeDialog = false
            pendingEngine = null
        },
        title = stringResource(R.string.read_aloud_default_engine),
        text = stringResource(R.string.speak_engine_apply_scope),
        confirmText = stringResource(R.string.general),
        onConfirm = {
            val opt = pendingEngine ?: return@AppAlertDialog
            showScopeDialog = false
            pendingEngine = null
            scope.launch {
                val msg = repo.applyEngine(opt.value, forBook = false)
                context.toastOnUi(msg)
                reload()
            }
        },
        dismissText = stringResource(R.string.book),
        onDismiss = {
            val opt = pendingEngine ?: return@AppAlertDialog
            showScopeDialog = false
            pendingEngine = null
            scope.launch {
                val msg = repo.applyEngine(opt.value, forBook = true)
                context.toastOnUi(msg)
                reload()
            }
        },
    )

    // ---------------- 删除确认 ----------------
    AppAlertDialog(
        show = showDeletePlugin != null,
        onDismissRequest = { showDeletePlugin = null },
        title = "删除插件",
        text = "确认删除插件「${showDeletePlugin?.name.orEmpty()}」？",
        confirmText = "删除",
        onConfirm = {
            val p = showDeletePlugin ?: return@AppAlertDialog
            showDeletePlugin = null
            scope.launch {
                repo.deletePlugin(p.pluginId)
                context.toastOnUi("已删除")
                reload()
            }
        },
        dismissText = "取消",
        onDismiss = { showDeletePlugin = null },
    )

    AppAlertDialog(
        show = showDeleteEntry != null,
        onDismissRequest = { showDeleteEntry = null },
        title = "删除声线配置",
        text = "确认删除 [${showDeleteEntry?.tag.orEmpty()}] ${showDeleteEntry?.displayName.orEmpty()} ？",
        confirmText = "删除",
        onConfirm = {
            val e = showDeleteEntry ?: return@AppAlertDialog
            showDeleteEntry = null
            scope.launch {
                repo.deleteEntry(e.tagRuleId, e.tag)
                context.toastOnUi("已删除")
                reload()
            }
        },
        dismissText = "取消",
        onDismiss = { showDeleteEntry = null },
    )

    AppAlertDialog(
        show = confirmDeleteGroup != null,
        onDismissRequest = { confirmDeleteGroup = null },
        title = "删除分组",
        text = "确认删除分组「${confirmDeleteGroup.orEmpty()}」及其全部条目？",
        confirmText = "删除",
        onConfirm = {
            val g = confirmDeleteGroup ?: return@AppAlertDialog
            confirmDeleteGroup = null
            scope.launch {
                repo.deleteGroup(g)
                context.toastOnUi("已删除分组")
                reload()
            }
        },
        dismissText = "取消",
        onDismiss = { confirmDeleteGroup = null },
    )

    AppAlertDialog(
        show = confirmDeleteSelEntries,
        onDismissRequest = { confirmDeleteSelEntries = false },
        title = "删除所选条目",
        text = "确认删除所选的 ${selEntries.size} 条声线配置？",
        confirmText = "删除",
        onConfirm = {
            confirmDeleteSelEntries = false
            scope.launch {
                repo.deleteEntries(selEntries)
                context.toastOnUi("已删除所选")
                entrySelMode = false
                selEntries = emptySet()
                reload()
            }
        },
        dismissText = "取消",
        onDismiss = { confirmDeleteSelEntries = false },
    )

    // ---------------- 重命名（条目/分组） ----------------
    AppAlertDialog(
        show = renameTarget != null,
        onDismissRequest = { renameTarget = null },
        title = "重命名声线",
        text = "当前：${renameTarget?.displayName.orEmpty()}",
        content = {
            AppTextField(
                value = renameText,
                onValueChange = { renameText = it },
                modifier = Modifier.fillMaxWidth(),
                label = "新显示名",
            )
        },
        confirmText = "保存",
        onConfirm = {
            val e = renameTarget ?: return@AppAlertDialog
            val name = renameText.trim()
            renameTarget = null
            if (name.isNotBlank()) {
                scope.launch {
                    val ok = repo.renameEntry(e.tagRuleId, e.tag, name)
                    context.toastOnUi(if (ok) "已重命名" else "未找到条目")
                    reload()
                }
            }
        },
        dismissText = "取消",
        onDismiss = { renameTarget = null },
    )

    AppAlertDialog(
        show = renameGroupTarget != null,
        onDismissRequest = { renameGroupTarget = null },
        title = "重命名分组：${renameGroupTarget.orEmpty()}",
        content = {
            AppTextField(
                value = renameGroupText,
                onValueChange = { renameGroupText = it },
                modifier = Modifier.fillMaxWidth(),
                label = "新分组名",
            )
        },
        confirmText = "保存",
        onConfirm = {
            val old = renameGroupTarget ?: return@AppAlertDialog
            renameGroupTarget = null
            scope.launch {
                val ok = repo.renameGroup(old, renameGroupText.trim())
                context.toastOnUi(if (ok) "已重命名" else "未找到分组")
                reload()
            }
        },
        dismissText = "取消",
        onDismiss = { renameGroupTarget = null },
    )

    // ---------------- 详情/结果 ----------------
    LogDetailSheet(
        show = detailText != null,
        title = detailTitle,
        content = detailText.orEmpty(),
        onDismissRequest = { detailText = null },
    )
}

@Composable
private fun FolderRow(
    title: String,
    collapsed: Boolean,
    indent: Boolean = false,
    trailing: (@Composable () -> Unit)? = null,
    onClick: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(start = if (indent) 28.dp else 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            imageVector = if (collapsed) Icons.Default.KeyboardArrowRight
            else Icons.Default.KeyboardArrowDown,
            contentDescription = null,
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(text = title, modifier = Modifier.weight(1f))
        trailing?.invoke()
    }
}

@Composable
private fun SheetField(label: String, value: String, onChange: (String) -> Unit) {
    AppTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier.fillMaxWidth(),
        label = label,
        singleLine = true,
    )
    Spacer(modifier = Modifier.height(8.dp))
}
