package io.legado.app.ui.ttssrv

import android.app.Application
import android.media.MediaPlayer
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import io.legado.app.R
import io.legado.app.data.repository.EngineOption
import io.legado.app.data.repository.EntryRow
import io.legado.app.data.repository.GroupRow
import io.legado.app.data.repository.PluginRow
import io.legado.app.data.repository.TtsServerCenterRepository
import io.legado.app.data.repository.VarField
import io.legado.app.ui.theme.adaptiveContentPadding
import io.legado.app.ui.widget.components.AppScaffold
import io.legado.app.ui.widget.components.AppTextField
import io.legado.app.ui.widget.components.SectionTitle
import io.legado.app.ui.widget.components.SplicedColumnGroup
import io.legado.app.ui.widget.components.alert.AppAlertDialog
import io.legado.app.ui.widget.components.filePicker.FilePickerSheet
import io.legado.app.ui.widget.components.log.LogDetailSheet
import io.legado.app.ui.widget.components.modalBottomSheet.AppModalBottomSheet
import io.legado.app.ui.widget.components.settingItem.TinyClickableSettingItem
import io.legado.app.ui.widget.components.tabRow.AppTabRow
import io.legado.app.ui.widget.components.topbar.GlassMediumFlexibleTopAppBar
import io.legado.app.ui.widget.components.topbar.GlassTopAppBarDefaults
import io.legado.app.ui.widget.components.topbar.TopBarActionButton
import io.legado.app.ui.widget.components.topbar.TopBarNavigationButton
import io.legado.app.utils.toastOnUi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * TTS-Server 管理中心（UI-1）：
 *  - 顶栏：返回 / 当前引擎(副标题) / 切换引擎 / 刷新
 *  - 页签：音色插件（导入导出/启停/变量/删除）｜配置列表（导入导出/试听/改名/删除）
 *  - 引擎切换：底部卡片选引擎 → "全局 / 本书" 范围弹窗（镜像原版云 TTS 交互）
 */
@Composable
fun TtsServerCenterRouteScreen(onBackClick: () -> Unit) {
    val context = LocalContext.current
    TtsServerCenterScreen(
        app = context.applicationContext as Application,
        onBack = onBackClick,
    )
}

private sealed interface CenterSheet {
    data class PluginActions(val plugin: PluginRow) : CenterSheet
    data class EntryActions(val entry: EntryRow) : CenterSheet
    data object ManualImport : CenterSheet
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun TtsServerCenterScreen(app: Application, onBack: () -> Unit) {
    val context = LocalContext.current
    val repo = remember(app) { TtsServerCenterRepository(app) }
    val scope = rememberCoroutineScope()

    var selectedTab by remember { mutableStateOf(0) }
    var plugins by remember { mutableStateOf<List<PluginRow>>(emptyList()) }
    var groups by remember { mutableStateOf<List<GroupRow>>(emptyList()) }
    var engineValue by remember { mutableStateOf<String?>(null) }
    var engineLoaded by remember { mutableStateOf(false) }
    var engineOptions by remember { mutableStateOf<List<EngineOption>>(emptyList()) }

    var sheet by remember { mutableStateOf<CenterSheet?>(null) }
    var showImportPicker by remember { mutableStateOf(false) }
    var importKind by remember { mutableStateOf(0) } // 0=插件 1=配置列表
    var detailTitle by remember { mutableStateOf("") }
    var detailText by remember { mutableStateOf<String?>(null) }

    var showEngineSheet by remember { mutableStateOf(false) }
    var pendingEngine by remember { mutableStateOf<EngineOption?>(null) }
    var showScopeDialog by remember { mutableStateOf(false) }

    var showDeletePlugin by remember { mutableStateOf<PluginRow?>(null) }
    var showDeleteEntry by remember { mutableStateOf<EntryRow?>(null) }
    var renameTarget by remember { mutableStateOf<EntryRow?>(null) }

    var importText by remember { mutableStateOf("") }
    var renameText by remember { mutableStateOf("") }
    var varsEditorPlugin by remember { mutableStateOf<PluginRow?>(null) }
    var varFields by remember { mutableStateOf<List<VarField>>(emptyList()) }
    val varValues = remember { mutableStateMapOf<String, String>() }
    val player = remember { MediaPlayer() }
    DisposableEffect(player) {
        onDispose { runCatching { player.release() } }
    }

    fun reload() {
        scope.launch {
            plugins = repo.loadPlugins()
            groups = repo.loadGroups()
            engineOptions = repo.loadEngineOptions()
            engineValue = repo.currentEngineValue()
            engineLoaded = true
        }
    }

    LaunchedEffect(Unit) { reload() }

    fun play(path: String) {
        runCatching {
            player.reset()
            player.setDataSource(path)
            player.prepare()
            player.start()
        }.onFailure {
            context.toastOnUi("播放失败：${it.message.orEmpty()}")
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val text = runCatching {
                    withContext(Dispatchers.IO) {
                        context.contentResolver.openInputStream(uri)
                            ?.bufferedReader()?.use { it.readText() }
                    }
                }.getOrNull()
                if (text.isNullOrBlank()) {
                    context.toastOnUi("读取文件为空或失败")
                } else {
                    val msg =
                        if (importKind == 0) repo.importPlugins(text) else repo.importVoices(text)
                    context.toastOnUi(msg)
                    reload()
                }
            }
        }
    }

    val scrollBehavior = GlassTopAppBarDefaults.defaultScrollBehavior()
    val engineSubtitle = if (!engineLoaded) "当前引擎：…" else "当前引擎：${repo.engineLabel(engineValue)}"

    AppScaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            GlassMediumFlexibleTopAppBar(
                title = stringResource(R.string.read_aloud_engines_and_voices),
                subtitle = engineSubtitle,
                scrollBehavior = scrollBehavior,
                navigationIcon = { TopBarNavigationButton(onClick = onBack) },
                actions = {
                    TopBarActionButton(
                        onClick = { showEngineSheet = true },
                        imageVector = Icons.Default.SwapHoriz,
                        contentDescription = "切换朗读引擎",
                    )
                    TopBarActionButton(
                        onClick = { reload() },
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "刷新",
                    )
                },
                bottomContent = {
                    AppTabRow(
                        tabTitles = listOf("音色插件", "配置列表"),
                        selectedTabIndex = selectedTab,
                        onTabSelected = { selectedTab = it },
                        isScrollable = false,
                    )
                }
            )
        },
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = adaptiveContentPadding(
                top = padding.calculateTopPadding() + 8.dp,
                bottom = padding.calculateBottomPadding() + 96.dp,
            ),
        ) {
            if (selectedTab == 0) {
                item {
                    SplicedColumnGroup(title = "插件操作") {
                        TinyClickableSettingItem(
                            title = "导入插件…",
                            description = "从文件选择 / 手动粘贴 JSON",
                            imageVector = Icons.Default.Upload,
                            onClick = {
                                importKind = 0
                                showImportPicker = true
                            },
                        )
                        TinyClickableSettingItem(
                            title = "导出全部插件",
                            description = "输出到 Download/chajian/_exports",
                            imageVector = Icons.Default.Download,
                            onClick = {
                                scope.launch {
                                    detailTitle = "导出完成（插件）"
                                    detailText = repo.exportPlugins()
                                }
                            },
                        )
                    }
                }
                item {
                    SplicedColumnGroup(title = "音色插件（${plugins.size}）") {
                        if (plugins.isEmpty()) {
                            TinyClickableSettingItem(
                                title = "暂无插件",
                                description = "先用上方导入插件 JSON",
                                onClick = {},
                            )
                        } else {
                            plugins.forEach { p ->
                                TinyClickableSettingItem(
                                    title = (if (p.enabled) "🟢 " else "⚪️ ") + p.name,
                                    description = "${p.pluginId} · v${p.version} · ${p.author}",
                                    onClick = { sheet = CenterSheet.PluginActions(p) },
                                )
                            }
                        }
                    }
                }
            } else {
                item {
                    SplicedColumnGroup(title = "列表操作") {
                        TinyClickableSettingItem(
                            title = "导入配置列表…",
                            description = "原生 [{group,list}] 或合集 JSON",
                            imageVector = Icons.Default.Upload,
                            onClick = {
                                importKind = 1
                                showImportPicker = true
                            },
                        )
                        TinyClickableSettingItem(
                            title = "导出配置列表",
                            description = "输出到 Download/chajian/_exports",
                            imageVector = Icons.Default.Download,
                            onClick = {
                                scope.launch {
                                    detailTitle = "导出完成（配置列表）"
                                    detailText = repo.exportVoices()
                                }
                            },
                        )
                    }
                }
                groups.forEach { g ->
                    item(key = "h_${g.name}") {
                        SectionTitle("${g.name}（${g.entries.size}）")
                    }
                    items(g.entries) { e ->
                        TinyClickableSettingItem(
                            title = "[${e.tag}] ${e.displayName}",
                            description = "${e.voice} · ${e.pluginId}",
                            onClick = { sheet = CenterSheet.EntryActions(e) },
                        )
                    }
                }
            }
        }
    }

    // ---------------- 导入选择 ----------------
    FilePickerSheet(
        show = showImportPicker,
        onDismissRequest = { showImportPicker = false },
        title = if (importKind == 0) "导入插件" else "导入配置列表",
        onSelectSysFile = { types ->
            showImportPicker = false
            importLauncher.launch(types)
        },
        onManualInput = {
            showImportPicker = false
            sheet = CenterSheet.ManualImport
        },
        allowExtensions = arrayOf("json", "txt"),
    )

    // ---------------- 手动粘贴 ----------------
    AppModalBottomSheet(
        show = sheet is CenterSheet.ManualImport,
        onDismissRequest = { sheet = null },
        title = if (importKind == 0) "粘贴插件 JSON" else "粘贴配置列表 JSON",
    ) {
        AppTextField(
            value = importText,
            onValueChange = { importText = it },
            modifier = Modifier.fillMaxWidth(),
            label = "粘贴 JSON 内容",
            minLines = 6,
            maxLines = 12,
        )
        Spacer(modifier = Modifier.height(12.dp))
        TinyClickableSettingItem(
            title = "从剪贴板粘贴",
            onClick = {
                val cm = context.getSystemService(android.content.ClipboardManager::class.java)
                val t = cm?.primaryClip?.takeIf { it.itemCount > 0 }
                    ?.getItemAt(0)?.coerceToText(context)?.toString()
                if (t.isNullOrBlank()) {
                    context.toastOnUi("剪贴板为空")
                } else {
                    importText = t
                    context.toastOnUi("已粘贴 ${t.length} 字符")
                }
            },
        )
        TinyClickableSettingItem(
            title = "确认导入",
            onClick = {
                val text = importText
                sheet = null
                importText = ""
                if (text.isBlank()) {
                    context.toastOnUi("内容为空")
                } else {
                    scope.launch {
                        val msg =
                            if (importKind == 0) repo.importPlugins(text) else repo.importVoices(text)
                        context.toastOnUi(msg)
                        reload()
                    }
                }
            },
        )
        TinyClickableSettingItem(title = "取消", onClick = { sheet = null })
    }

    // ---------------- 插件操作 ----------------
    AppModalBottomSheet(
        show = sheet is CenterSheet.PluginActions,
        onDismissRequest = { sheet = null },
        title = (sheet as? CenterSheet.PluginActions)?.plugin?.name ?: "插件操作",
    ) {
        val p = (sheet as? CenterSheet.PluginActions)?.plugin
        if (p != null) {
            TinyClickableSettingItem(
                title = if (p.enabled) "停用插件" else "启用插件",
                onClick = {
                    sheet = null
                    scope.launch {
                        repo.setPluginEnabled(p.pluginId, !p.enabled)
                        context.toastOnUi(if (p.enabled) "已停用" else "已启用")
                        reload()
                    }
                },
            )
            TinyClickableSettingItem(
                title = "编辑变量（如 APIKEY 等）",
                description = "按插件定义的表单填写并保存",
                onClick = {
                    sheet = null
                    scope.launch {
                        val fields = repo.loadVarFields(p.pluginId)
                        varValues.clear()
                        fields.forEach { varValues[it.key] = it.value }
                        varFields = fields
                        varsEditorPlugin = p
                    }
                },
            )
            TinyClickableSettingItem(
                title = "查看原始 JSON（defVars / userVars）",
                onClick = {
                    sheet = null
                    scope.launch {
                        detailTitle = "插件变量（原始）"
                        detailText = repo.pluginVarsText(p.pluginId)
                    }
                },
            )
            TinyClickableSettingItem(
                title = "导出此插件",
                onClick = {
                    sheet = null
                    scope.launch {
                        detailTitle = "导出完成"
                        detailText = repo.exportPlugin(p.pluginId)
                    }
                },
            )
            TinyClickableSettingItem(
                title = "删除插件",
                onClick = {
                    sheet = null
                    showDeletePlugin = p
                },
            )
        }
    }

    // ---------------- 声线条目操作 ----------------
    AppModalBottomSheet(
        show = sheet is CenterSheet.EntryActions,
        onDismissRequest = { sheet = null },
        title = (sheet as? CenterSheet.EntryActions)?.entry?.let {
            "[${it.tag}] ${it.displayName}"
        } ?: "声线条目",
    ) {
        val e = (sheet as? CenterSheet.EntryActions)?.entry
        if (e != null) {
            TinyClickableSettingItem(
                title = "试听（合成并播放）",
                description = "走 内置引擎 → 标签 ${e.tag}",
                imageVector = Icons.Default.PlayArrow,
                onClick = {
                    sheet = null
                    scope.launch {
                        context.toastOnUi("正在合成…")
                        val r = repo.auditionDetailed(
                            e.tagRuleId, e.tag, "你好，这里是移植层试听。"
                        )
                        if (r.ok && r.path != null) {
                            play(r.path)
                            context.toastOnUi("播放中：${r.path.substringAfterLast('/')}")
                        } else {
                            detailTitle = "试听失败（诊断报告）"
                            detailText = r.message
                            context.toastOnUi("合成失败（详情已弹出）")
                        }
                    }
                },
            )
            TinyClickableSettingItem(
                title = "重命名显示名",
                description = "当前：${e.displayName}",
                onClick = {
                    renameText = e.displayName
                    sheet = null
                    renameTarget = e
                },
            )
            TinyClickableSettingItem(
                title = "删除此声线配置",
                onClick = {
                    sheet = null
                    showDeleteEntry = e
                },
            )
        }
    }

    // ---------------- 引擎切换 ----------------
    AppModalBottomSheet(
        show = showEngineSheet,
        onDismissRequest = { showEngineSheet = false },
        title = "切换朗读引擎",
    ) {
        engineOptions.forEach { opt ->
            val current = (opt.value == null && engineValue.isNullOrBlank()) ||
                    (opt.value != null && opt.value == engineValue)
            TinyClickableSettingItem(
                title = (if (current) "✓ " else "") + opt.label,
                onClick = {
                    showEngineSheet = false
                    pendingEngine = opt
                    showScopeDialog = true
                },
            )
        }
    }

    AppAlertDialog(
        show = showScopeDialog,
        onDismissRequest = {
            showScopeDialog = false
            pendingEngine = null
        },
        title = stringResource(R.string.read_aloud_default_engine),
        text = stringResource(R.string.speak_engine_apply_scope),
        confirmText = stringResource(R.string.general),
        onConfirm = {
            val opt = pendingEngine ?: return@AppAlertDialog
            showScopeDialog = false
            pendingEngine = null
            scope.launch {
                val msg = repo.applyEngine(opt.value, forBook = false)
                context.toastOnUi(msg)
                reload()
            }
        },
        dismissText = stringResource(R.string.book),
        onDismiss = {
            val opt = pendingEngine ?: return@AppAlertDialog
            showScopeDialog = false
            pendingEngine = null
            scope.launch {
                val msg = repo.applyEngine(opt.value, forBook = true)
                context.toastOnUi(msg)
                reload()
            }
        },
    )

    // ---------------- 删除确认 ----------------
    AppAlertDialog(
        show = showDeletePlugin != null,
        onDismissRequest = { showDeletePlugin = null },
        title = "删除插件",
        text = "确认删除插件「${showDeletePlugin?.name.orEmpty()}」？",
        confirmText = "删除",
        onConfirm = {
            val p = showDeletePlugin ?: return@AppAlertDialog
            showDeletePlugin = null
            scope.launch {
                repo.deletePlugin(p.pluginId)
                context.toastOnUi("已删除")
                reload()
            }
        },
        dismissText = "取消",
        onDismiss = { showDeletePlugin = null },
    )

    AppAlertDialog(
        show = showDeleteEntry != null,
        onDismissRequest = { showDeleteEntry = null },
        title = "删除声线配置",
        text = "确认删除 [${showDeleteEntry?.tag.orEmpty()}] ${showDeleteEntry?.displayName.orEmpty()} ？",
        confirmText = "删除",
        onConfirm = {
            val e = showDeleteEntry ?: return@AppAlertDialog
            showDeleteEntry = null
            scope.launch {
                repo.deleteEntry(e.tagRuleId, e.tag)
                context.toastOnUi("已删除")
                reload()
            }
        },
        dismissText = "取消",
        onDismiss = { showDeleteEntry = null },
    )

    // ---------------- 重命名 ----------------
    AppAlertDialog(
        show = renameTarget != null,
        onDismissRequest = { renameTarget = null },
        title = "重命名声线",
        text = "当前：${renameTarget?.displayName.orEmpty()}",
        content = {
            AppTextField(
                value = renameText,
                onValueChange = { renameText = it },
                modifier = Modifier.fillMaxWidth(),
                label = "新显示名",
            )
        },
        confirmText = "保存",
        onConfirm = {
            val e = renameTarget ?: return@AppAlertDialog
            val name = renameText.trim()
            renameTarget = null
            if (name.isNotBlank()) {
                scope.launch {
                    val ok = repo.renameEntry(e.tagRuleId, e.tag, name)
                    context.toastOnUi(if (ok) "已重命名" else "未找到条目")
                    reload()
                }
            }
        },
        dismissText = "取消",
        onDismiss = { renameTarget = null },
    )

    // ---------------- 变量编辑 ----------------
    AppModalBottomSheet(
        show = varsEditorPlugin != null,
        onDismissRequest = { varsEditorPlugin = null },
        title = "编辑变量：${varsEditorPlugin?.name.orEmpty()}",
    ) {
        if (varFields.isEmpty()) {
            TinyClickableSettingItem(title = "此插件未定义变量", onClick = {})
        }
        varFields.forEach { f ->
            AppTextField(
                value = varValues[f.key] ?: "",
                onValueChange = { varValues[f.key] = it },
                modifier = Modifier.fillMaxWidth(),
                label = if (f.description.isNotBlank()) {
                    "${f.label}（${f.description}）"
                } else {
                    f.label
                },
                singleLine = true,
            )
            Spacer(modifier = Modifier.height(8.dp))
        }
        Spacer(modifier = Modifier.height(4.dp))
        TinyClickableSettingItem(
            title = "保存变量（保存后引擎缓存自动刷新）",
            onClick = {
                val p = varsEditorPlugin ?: return@TinyClickableSettingItem
                varsEditorPlugin = null
                scope.launch {
                    val ok = repo.savePluginUserVars(p.pluginId, varValues.toMap())
                    context.toastOnUi(if (ok) "变量已保存" else "保存失败")
                    reload()
                }
            },
        )
    }

    // ---------------- 详情/结果 ----------------
    LogDetailSheet(
        show = detailText != null,
        title = detailTitle,
        content = detailText.orEmpty(),
        onDismissRequest = { detailText = null },
    )
}
