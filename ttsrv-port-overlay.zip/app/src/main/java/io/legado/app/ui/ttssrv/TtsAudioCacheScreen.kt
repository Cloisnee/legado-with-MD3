package io.legado.app.ui.ttssrv

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import io.legado.app.ui.book.readaloud.cache.TtsCacheDialog
import io.legado.app.ui.book.readaloud.cache.TtsCacheEffect
import io.legado.app.ui.book.readaloud.cache.TtsCacheIntent
import io.legado.app.ui.book.readaloud.cache.TtsCacheUiState
import io.legado.app.ui.book.readaloud.cache.TtsCacheViewModel
import io.legado.app.ui.theme.adaptiveContentPadding
import io.legado.app.ui.widget.components.AppFloatingActionButton
import io.legado.app.ui.widget.components.AppScaffold
import io.legado.app.ui.widget.components.alert.AppAlertDialog
import io.legado.app.ui.widget.components.button.series.SmallPlainButton
import io.legado.app.ui.widget.components.log.LogDetailSheet
import io.legado.app.ui.widget.components.settingItem.TinyClickableSettingItem
import io.legado.app.ui.widget.components.topbar.GlassMediumFlexibleTopAppBar
import io.legado.app.ui.widget.components.topbar.GlassTopAppBarDefaults
import io.legado.app.ui.widget.components.topbar.TopBarNavigationButton
import io.legado.app.utils.toastOnUi
import kotlinx.coroutines.flow.collectLatest
import org.koin.androidx.compose.koinViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 朗读音频缓存管理（从「缓存管理」进入；由原朗读缓存页拆分而来）。
 * 复用 TtsCacheViewModel 的文件列表 / 删除 / 清空能力。
 */
@Composable
fun TtsAudioCacheRouteScreen(
    onBackClick: () -> Unit,
    viewModel: TtsCacheViewModel = koinViewModel(),
) {
    LaunchedEffect(Unit) {
        viewModel.onIntent(TtsCacheIntent.LoadCache)
    }
    val context = LocalContext.current
    LaunchedEffect(viewModel) {
        viewModel.effects.collectLatest { effect ->
            when (effect) {
                is TtsCacheEffect.ShowToast -> context.toastOnUi(effect.message)
            }
        }
    }
    val state = viewModel.uiState.collectAsStateWithLifecycle().value
    TtsAudioCacheScreen(
        state = state,
        onIntent = viewModel::onIntent,
        onBackClick = onBackClick,
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TtsAudioCacheScreen(
    state: TtsCacheUiState,
    onIntent: (TtsCacheIntent) -> Unit,
    onBackClick: () -> Unit,
) {
    val scrollBehavior = GlassTopAppBarDefaults.defaultScrollBehavior()
    val dateFormat = remember { SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()) }

    AppScaffold(
        modifier = Modifier.nestedScroll(scrollBehavior.nestedScrollConnection),
        topBar = {
            GlassMediumFlexibleTopAppBar(
                title = "朗读音频缓存",
                scrollBehavior = scrollBehavior,
                navigationIcon = {
                    TopBarNavigationButton(onClick = onBackClick)
                },
            )
        },
        floatingActionButton = {
            if (state.files.isNotEmpty()) {
                AppFloatingActionButton(
                    onClick = { onIntent(TtsCacheIntent.ShowClearAllDialog) },
                    icon = Icons.Default.DeleteSweep,
                    tooltipText = "清空缓存",
                )
            }
        },
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = adaptiveContentPadding(
                top = paddingValues.calculateTopPadding() + 8.dp,
                bottom = paddingValues.calculateBottomPadding() + 96.dp,
            ),
        ) {
            item {
                val sizeText = TtsCacheViewModel.formatSize(state.totalSizeBytes)
                TinyClickableSettingItem(
                    title = "总计",
                    description = "$sizeText · ${state.files.size} 个文件",
                    onClick = {},
                )
            }
            if (state.files.isEmpty() && !state.loading) {
                item {
                    TinyClickableSettingItem(
                        title = "暂无朗读音频缓存",
                        description = "播放朗读内容后会在此处生成缓存",
                        onClick = {},
                    )
                }
            }
            items(state.files, key = { it.name }) { file ->
                val sizeText = TtsCacheViewModel.formatSize(file.sizeBytes)
                val dateText = dateFormat.format(Date(file.lastModified))
                val displayText = file.text.ifEmpty { file.name }
                TinyClickableSettingItem(
                    title = displayText,
                    description = "$sizeText · $dateText",
                    trailingContent = {
                        SmallPlainButton(
                            icon = Icons.Default.Delete,
                            contentDescription = "删除",
                            onClick = { onIntent(TtsCacheIntent.DeleteFile(file.name)) },
                        )
                    },
                    onClick = {
                        onIntent(
                            TtsCacheIntent.ShowFileDetail(
                                name = file.name,
                                text = file.text,
                                sizeBytes = file.sizeBytes,
                                lastModified = file.lastModified,
                            )
                        )
                    },
                )
            }
        }
    }

    AppAlertDialog(
        show = state.activeDialog == TtsCacheDialog.ClearAll,
        onDismissRequest = { onIntent(TtsCacheIntent.DismissDialog) },
        title = "清空朗读音频缓存",
        text = "确认清空全部朗读音频缓存文件？",
        onConfirm = { onIntent(TtsCacheIntent.ClearAll) },
        onDismiss = { onIntent(TtsCacheIntent.DismissDialog) },
    )

    LogDetailSheet(
        show = state.showDetail,
        title = state.detailTitle,
        content = state.detailContent,
        onDismissRequest = { onIntent(TtsCacheIntent.DismissDetail) },
    )
}
