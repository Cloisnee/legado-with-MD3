package io.legado.app.data.repository

import android.app.Application
import android.content.Context
import com.github.jing332.compat.fs.TtsDirProvider
import com.github.jing332.database.entities.systts.source.PluginTtsSource
import com.github.jing332.tts.speech.plugin.engine.TtsEngineContext
import com.github.jing332.tts.store.TtsConfigStore
import io.legado.app.data.appDb
import io.legado.app.domain.gateway.ReadAloudSettingsGateway
import io.legado.app.domain.model.readaloud.ReadAloudEngineSelection
import io.legado.app.model.ReadAloud
import io.legado.app.model.ReadBook
import io.legado.app.utils.GSON
import io.legado.app.utils.fromJsonObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * TTS-Server 管理中心 · 数据层（UI-1）
 * 直接操作 TtsConfigStore（插件 / 配置列表），引擎选择走原版 ttsEngine 字段。
 */
data class PluginRow(
    val pluginId: String,
    val name: String,
    val author: String,
    val version: Int,
    val enabled: Boolean,
)

data class EntryRow(
    val id: Long,
    val displayName: String,
    val tag: String,
    val tagRuleId: String,
    val pluginId: String,
    val locale: String,
    val voice: String,
)

data class GroupRow(
    val name: String,
    val entries: List<EntryRow>,
)

data class EngineOption(val value: String?, val label: String)

class TtsServerCenterRepository(private val app: Application) {

    companion object {
        const val BUILTIN_ENGINE_JSON =
            """{"engineType":"tts_server","engineId":"","speakerId":"","displayName":"内置引擎"}"""
    }

    private val ctx: Context get() = app

    // ---------------- 读取 ----------------

    suspend fun loadPlugins(): List<PluginRow> = withContext(Dispatchers.IO) {
        val arr = TtsConfigStore.loadPlugins(ctx)
        buildList {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("pluginId").ifBlank { o.optString("id") }
                if (id.isBlank()) continue
                add(
                    PluginRow(
                        pluginId = id,
                        name = o.optString("name", id),
                        author = o.optString("author"),
                        version = o.opt("version")?.toString()
                            ?.let { v -> Regex("\\d+").find(v)?.value?.toIntOrNull() } ?: 0,
                        enabled = if (o.has("isEnabled")) o.optBoolean("isEnabled", true)
                        else o.optBoolean("enabled", true),
                    )
                )
            }
        }
    }

    suspend fun loadGroups(): List<GroupRow> = withContext(Dispatchers.IO) {
        val arr = TtsConfigStore.loadVoices(ctx)
        buildList {
            for (g in 0 until arr.length()) {
                val grp = arr.optJSONObject(g) ?: continue
                val name = grp.optJSONObject("group")?.optString("name") ?: "未命名分组"
                val list = grp.optJSONArray("list") ?: JSONArray()
                val entries = buildList {
                    for (i in 0 until list.length()) {
                        val e = list.optJSONObject(i) ?: continue
                        val cfg = e.optJSONObject("config") ?: continue
                        val sr = cfg.optJSONObject("speechRule") ?: continue
                        val src = cfg.optJSONObject("source")
                        add(
                            EntryRow(
                                id = e.optLong("id"),
                                displayName = e.optString("displayName"),
                                tag = sr.optString("tag"),
                                tagRuleId = sr.optString("tagRuleId"),
                                pluginId = src?.optString("pluginId").orEmpty(),
                                locale = src?.optString("locale").orEmpty(),
                                voice = src?.optString("voice").orEmpty(),
                            )
                        )
                    }
                }
                add(GroupRow(name = name, entries = entries))
            }
        }
    }

    // ---------------- 引擎选择 ----------------

    suspend fun loadEngineOptions(): List<EngineOption> = withContext(Dispatchers.IO) {
        buildList {
            add(EngineOption(null, "系统 TTS"))
            add(EngineOption(BUILTIN_ENGINE_JSON, "内置引擎（TTS Server）"))
            runCatching {
                appDb.httpTTSDao.all.forEach { h ->
                    add(EngineOption(h.id.toString(), "在线朗读 · ${h.name}"))
                }
            }
        }
    }

    fun currentEngineValue(): String? =
        ReadBook.book?.getTtsEngine() ?: gateway().currentSettings.ttsEngine

    fun engineLabel(value: String?): String = when {
        value.isNullOrBlank() -> "系统 TTS"
        value.all { it.isDigit() } -> runCatching {
            appDb.httpTTSDao.get(value.toLong())?.name?.let { "在线朗读 · $it" }
        }.getOrNull() ?: "在线朗读"
        value.contains("tts_server") -> "内置引擎"
        else -> GSON.fromJsonObject<ReadAloudEngineSelection>(value).getOrNull()
            ?.displayName?.takeIf { it.isNotBlank() } ?: "在线朗读"
    }

    private fun gateway(): ReadAloudSettingsGateway =
        org.koin.core.context.GlobalContext.get().get()

    /** 应用引擎选择（镜像云 TTS 的 applyDefaultEngine 语义：本书写 Book / 全局写设置） */
    suspend fun applyEngine(value: String?, forBook: Boolean): String {
        val book = ReadBook.book
        if (forBook && book != null) {
            book.setTtsEngine(value)
            withContext(Dispatchers.IO) {
                appDb.bookDao.getBook(book.bookUrl)?.let { b ->
                    b.setTtsEngine(value)
                    appDb.bookDao.update(b)
                }
            }
        } else {
            book?.setTtsEngine(null)
            val url = book?.bookUrl
            if (url != null) {
                withContext(Dispatchers.IO) {
                    appDb.bookDao.getBook(url)?.let { b ->
                        b.setTtsEngine(null)
                        appDb.bookDao.update(b)
                    }
                }
            }
            gateway().update { it.copy(ttsEngine = value) }
        }
        withContext(Dispatchers.Main) { ReadAloud.upReadAloudClass() }
        return if (forBook && book != null) "已应用到本书" else "已设为全局"
    }

    // ---------------- 插件操作 ----------------

    suspend fun setPluginEnabled(pluginId: String, enabled: Boolean): Boolean =
        withContext(Dispatchers.IO) {
            runCatching {
                val file = TtsConfigStore.pluginsFile(ctx)
                val arr = JSONArray(file.readText().removePrefix("\uFEFF"))
                var hit = false
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val id = o.optString("pluginId").ifBlank { o.optString("id") }
                    if (id == pluginId) {
                        o.put("isEnabled", enabled)
                        hit = true
                    }
                }
                if (hit) file.writeText(arr.toString())
                hit
            }.getOrDefault(false)
        }

    suspend fun deletePlugin(pluginId: String): Boolean = withContext(Dispatchers.IO) {
        runCatching {
            val file = TtsConfigStore.pluginsFile(ctx)
            val arr = JSONArray(file.readText().removePrefix("\uFEFF"))
            val out = JSONArray()
            var hit = false
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("pluginId").ifBlank { o.optString("id") }
                if (id == pluginId) hit = true else out.put(o)
            }
            if (hit) file.writeText(out.toString())
            hit
        }.getOrDefault(false)
    }

    suspend fun pluginVarsText(pluginId: String): String = withContext(Dispatchers.IO) {
        runCatching {
            val arr = TtsConfigStore.loadPlugins(ctx)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("pluginId").ifBlank { o.optString("id") }
                if (id == pluginId) {
                    return@runCatching buildString {
                        appendLine("插件：${o.optString("name")} ($id)")
                        appendLine()
                        appendLine("defVars（插件定义变量）：")
                        appendLine(o.optJSONObject("defVars")?.toString(2) ?: "{}")
                        appendLine()
                        appendLine("userVars（用户变量）：")
                        appendLine(o.optJSONObject("userVars")?.toString(2) ?: "{}")
                    }
                }
            }
            "插件不存在：$pluginId"
        }.getOrDefault("读取失败")
    }

    // ---------------- 声线条目操作 ----------------

    suspend fun renameEntry(ruleId: String, tag: String, newName: String): Boolean =
        withContext(Dispatchers.IO) { TtsConfigStore.updateDisplayName(ctx, ruleId, tag, newName) }

    suspend fun deleteEntry(ruleId: String, tag: String): Boolean =
        withContext(Dispatchers.IO) { TtsConfigStore.deleteConfig(ctx, ruleId, tag) }

    /** 试听：按标签合成到 _audition 并返回文件路径 */
    suspend fun audition(ruleId: String, tag: String, text: String): String? =
        withContext(Dispatchers.IO) {
            runCatching {
                TtsEngineContext(
                    tts = PluginTtsSource(),
                    userVars = emptyMap(),
                    context = ctx,
                    engineId = ruleId,
                ).getAudioByTag(tag, text)
            }.getOrNull()
        }

    // ---------------- 导入导出 ----------------

    private fun exportsDir(): File =
        File(TtsDirProvider.baseDir(ctx), "_exports").apply { mkdirs() }

    private fun ts(): String =
        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())

    suspend fun exportPlugins(): String = withContext(Dispatchers.IO) {
        val arr = TtsConfigStore.loadPlugins(ctx)
        val f = File(exportsDir(), "plugins_${ts()}.json")
        f.writeText(arr.toString())
        f.absolutePath
    }

    suspend fun exportPlugin(pluginId: String): String = withContext(Dispatchers.IO) {
        runCatching {
            val arr = TtsConfigStore.loadPlugins(ctx)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("pluginId").ifBlank { o.optString("id") }
                if (id == pluginId) {
                    val f = File(exportsDir(), "plugin_${pluginId}_${ts()}.json")
                    f.writeText(JSONArray().put(o).toString())
                    return@runCatching f.absolutePath
                }
            }
            "插件不存在：$pluginId"
        }.getOrDefault("导出失败")
    }

    suspend fun exportVoices(): String = withContext(Dispatchers.IO) {
        val arr = TtsConfigStore.loadVoices(ctx)
        val f = File(exportsDir(), "voices_${ts()}.json")
        f.writeText(arr.toString())
        f.absolutePath
    }

    suspend fun importPlugins(text: String): String = withContext(Dispatchers.IO) {
        runCatching {
            val t = text.trim().removePrefix("\uFEFF")
            val arr = when {
                t.startsWith("[") -> JSONArray(t)
                t.startsWith("{") -> {
                    val o = JSONObject(t)
                    o.optJSONArray("plugins") ?: JSONArray().put(o)
                }

                else -> error("无法解析：既不是数组也不是对象")
            }
            val (a, r, s) = TtsConfigStore.importPlugins(ctx, arr)
            "导入插件完成：新增=$a 覆盖=$r 跳过=$s"
        }.getOrElse { "导入失败：${it.message ?: it.javaClass.simpleName}" }
    }

    suspend fun importVoices(text: String): String = withContext(Dispatchers.IO) {
        runCatching {
            val t = text.trim().removePrefix("\uFEFF")
            val arr = JSONArray(t)
            val (ae, re, ag) = TtsConfigStore.importVoices(ctx, arr)
            "导入配置列表完成：新增条目=$ae 覆盖条目=$re 新增分组=$ag"
        }.getOrElse { "导入失败：${it.message ?: it.javaClass.simpleName}" }
    }
}
