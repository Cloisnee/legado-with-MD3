#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TTS-Server 移植补丁器（幂等）— 在 legado-with-MD3 的 fork 中运行
用法: python3 apply_patch.py [repo_root]

作用:
  1) settings.gradle(.kts) 注册 modules/lib-common|lib-script|lib-tts
  2) app/build.gradle.kts 增加 implementation(project(":modules:lib-tts"))
  3) App.kt 注入 HostHttp（延迟解析宿主 okHttpClient；找不到锚点时跳过且不报错）
"""
import sys, pathlib

root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else '.')
print('repo root =', root.resolve())
changed = []


def patch(rel, fn, label):
    p = root / rel
    if not p.exists():
        print(f'[跳过] {label}: 找不到 {rel}')
        return
    t = p.read_text(encoding='utf-8')
    nt = fn(t)
    if nt != t:
        p.write_text(nt, encoding='utf-8')
        changed.append(label)
        print(f'[已修改] {label}')
    else:
        print(f'[不动]  {label}（已是目标状态）')


def f_settings_groovy(t):
    mods = [":modules:lib-common", ":modules:lib-script", ":modules:lib-tts"]
    lines = [f"include '{m}'" for m in mods if f"include '{m}'" not in t]
    if not lines:
        return t
    anchor = "include ':modules:rhino'"
    if anchor in t:
        return t.replace(anchor, anchor + "\n" + "\n".join(lines), 1)
    return t.rstrip() + "\n" + "\n".join(lines) + "\n"


def f_settings_kts(t):
    mods = [":modules:lib-common", ":modules:lib-script", ":modules:lib-tts"]
    lines = [f'include("{m}")' for m in mods if f'include("{m}")' not in t]
    if not lines:
        return t
    anchor = 'include(":modules:rhino")'
    if anchor in t:
        return t.replace(anchor, anchor + "\n" + "\n".join(lines), 1)
    return t.rstrip() + "\n" + "\n".join(lines) + "\n"


def f_app_gradle(t):
    line = 'implementation(project(":modules:lib-tts"))'
    if line in t:
        return t
    anchor = 'implementation(project(":modules:rhino"))'
    if anchor in t:
        return t.replace(anchor, anchor + "\n    " + line, 1)
    anchor2 = 'androidTestImplementation(libs.room.testing)'
    if anchor2 in t:
        return t.replace(anchor2, line + "\n    " + anchor2, 1)
    raise SystemExit('[错误] app/build.gradle.kts 未找到依赖插入点')


def f_app_kt(t):
    anchor = '        AppConfigStore.init(this)'
    todo = []
    if 'HostHttp.init' not in t:
        todo.append('        com.github.jing332.compat.net.HostHttp.init { io.legado.app.help.http.okHttpClient }')
    if 'SmokeRunner' not in t:
        todo.append('        com.github.jing332.tts.debug.SmokeRunner.run(this)')
    if 'OpsRunner' not in t:
        todo.append('        com.github.jing332.tts.debug.OpsRunner.run(this)')
    if not todo:
        return t
    if anchor in t:
        block = (anchor + "\n        // [TTS-Server 移植] 网络桥注入 + 冒烟自检 + _ops 指令通道（后台运行，不阻塞启动）\n"
                 + "\n".join(todo))
        return t.replace(anchor, block, 1)
    # 兜底：若已有部分注入行，把缺失的补在最后一条注入行之后
    best_idx, best_marker = -1, None
    for m in ['com.github.jing332.tts.debug.OpsRunner.run(this)',
              'com.github.jing332.tts.debug.SmokeRunner.run(this)',
              'com.github.jing332.compat.net.HostHttp.init']:
        i = t.find(m)
        if i > best_idx:
            best_idx, best_marker = i, m
    if best_marker is not None:
        eol = t.find('\n', best_idx)
        if eol > 0:
            return t[:eol] + '\n' + '\n'.join(todo) + t[eol:]
    print('  [警告] App.kt 未找到注入锚点，跳过')
    return t


if (root / 'settings.gradle').exists():
    patch('settings.gradle', f_settings_groovy, 'settings.gradle')
elif (root / 'settings.gradle.kts').exists():
    patch('settings.gradle.kts', f_settings_kts, 'settings.gradle.kts')
else:
    print('[跳过] settings 文件不存在')

patch('app/build.gradle.kts', f_app_gradle, 'app/build.gradle.kts')
patch('app/src/main/java/io/legado/app/App.kt', f_app_kt, 'App.kt')


# ============================================================
# 阶段2 · 朗读管线接入（engineType = "tts_server"）
# ============================================================
def f_readaloud_speech_models(t):
    if 'ENGINE_TTS_SERVER' in t:
        return t
    old = '        const val ENGINE_CLOUD = "cloud_tts"\n'
    if old not in t:
        print('  [跳补丁·未命中] ReadAloudSpeechModels 常量锚点')
        return t
    return t.replace(old, old + '        const val ENGINE_TTS_SERVER = "tts_server"\n', 1)


def f_http_readaloud_service(t):
    if 'TtsServerSynthesizer' in t:
        return t
    pairs = [
        # 1) 合成器声明
        (
            '    private val cloudTtsAudioSynthesizer by lazy {\n'
            '        CloudTtsAudioSynthesizer(get(CloudTtsEngineGateway::class.java))\n'
            '    }\n',
            '    private val cloudTtsAudioSynthesizer by lazy {\n'
            '        CloudTtsAudioSynthesizer(get(CloudTtsEngineGateway::class.java))\n'
            '    }\n'
            '    // [TTS-Server 移植] 内嵌引擎合成器（engineType = tts_server）\n'
            '    private val ttsServerSynthesizer by lazy {\n'
            '        com.github.jing332.tts.readaloud.TtsServerSynthesizer(this)\n'
            '    }\n',
        ),
        # 2) 主合成 when：CLOUD 分支前插入
        (
            '                                ReadAloudVoice.ENGINE_CLOUD -> {\n'
            '                                    val output = getSpeakFileAsMd5(fileName)\n'
            '                                    if (!cloudTtsAudioSynthesizer.synthesize(',
            '                                ReadAloudVoice.ENGINE_TTS_SERVER -> {\n'
            '                                    val output = getSpeakFileAsMd5(fileName)\n'
            '                                    if (!ttsServerSynthesizer.synthesize(\n'
            '                                            routedVoice.engineId,\n'
            '                                            routedVoice.speakerId,\n'
            '                                            speakText,\n'
            '                                            output,\n'
            '                                        )\n'
            '                                    ) {\n'
            '                                        createSilentSound(fileName)\n'
            '                                    }\n'
            '                                }\n'
            '\n'
            '                                ReadAloudVoice.ENGINE_CLOUD -> {\n'
            '                                    val output = getSpeakFileAsMd5(fileName)\n'
            '                                    if (!cloudTtsAudioSynthesizer.synthesize(',
        ),
        # 3) 单 cue 合成 when：CLOUD 分支前插入
        (
            '                ReadAloudVoice.ENGINE_CLOUD -> {\n'
            '                    val output = getSpeakFileAsMd5(fileName)\n'
            '                    cloudTtsAudioSynthesizer.synthesize(',
            '                ReadAloudVoice.ENGINE_TTS_SERVER -> {\n'
            '                    val output = getSpeakFileAsMd5(fileName)\n'
            '                    ttsServerSynthesizer.synthesize(\n'
            '                        routedVoice.engineId,\n'
            '                        routedVoice.speakerId,\n'
            '                        speakText,\n'
            '                        output,\n'
            '                    )\n'
            '                }\n'
            '\n'
            '                ReadAloudVoice.ENGINE_CLOUD -> {\n'
            '                    val output = getSpeakFileAsMd5(fileName)\n'
            '                    cloudTtsAudioSynthesizer.synthesize(',
        ),
        # 4) 预下载条件
        (
            '                    if (routedVoice.engineType == ReadAloudVoice.ENGINE_CLOUD) {',
            '                    if (routedVoice.engineType == ReadAloudVoice.ENGINE_CLOUD ||\n'
            '                        routedVoice.engineType == ReadAloudVoice.ENGINE_TTS_SERVER) {',
        ),
        # 5) sourceKeyForCue：ELSE 前插入分支
        (
            '            else -> {\n'
            '                val itemHttpTts = routedVoice.engineId.toLongOrNull()\n'
            '                    ?.let(appDb.httpTTSDao::get) ?: httpTts\n'
            '                itemHttpTts.url\n'
            '            }',
            '            ReadAloudVoice.ENGINE_TTS_SERVER ->\n'
            '                "tts_server:${routedVoice.id}:${routedVoice.revision}:" +\n'
            '                        "${routedVoice.engineId}:${routedVoice.speakerId}:$cueEmotion"\n'
            '\n'
            '            else -> {\n'
            '                val itemHttpTts = routedVoice.engineId.toLongOrNull()\n'
            '                    ?.let(appDb.httpTTSDao::get) ?: httpTts\n'
            '                itemHttpTts.url\n'
            '            }',
        ),
        # 6) voiceForCue 支持集
        (
            '            supportedEngineTypes = setOf(\n'
            '                ReadAloudVoice.ENGINE_HTTP,\n'
            '                ReadAloudVoice.ENGINE_SYSTEM,\n'
            '                ReadAloudVoice.ENGINE_CLOUD,\n'
            '            ),',
            '            supportedEngineTypes = setOf(\n'
            '                ReadAloudVoice.ENGINE_HTTP,\n'
            '                ReadAloudVoice.ENGINE_SYSTEM,\n'
            '                ReadAloudVoice.ENGINE_CLOUD,\n'
            '                ReadAloudVoice.ENGINE_TTS_SERVER,\n'
            '            ),',
        ),
        # 7) hasFileSynthesisCue 集合
        (
            '            setOf(\n'
            '                ReadAloudVoice.ENGINE_SYSTEM,\n'
            '                ReadAloudVoice.ENGINE_CLOUD,\n'
            '            )',
            '            setOf(\n'
            '                ReadAloudVoice.ENGINE_SYSTEM,\n'
            '                ReadAloudVoice.ENGINE_CLOUD,\n'
            '                ReadAloudVoice.ENGINE_TTS_SERVER,\n'
            '            )',
        ),
    ]
    for old, new in pairs:
        if old not in t:
            print('  [跳补丁·未命中] HttpReadAloudService: ' + repr(old[:70]))
            continue
        t = t.replace(old, new, 1)
    return t


def f_readaloud_model(t):
    if 'ENGINE_TTS_SERVER' in t:
        return t
    old = ('                    it.id in voiceIds && it.engineType in setOf(\n'
           '                        ReadAloudVoice.ENGINE_HTTP,\n'
           '                        ReadAloudVoice.ENGINE_CLOUD,\n'
           '                    ) &&')
    new = ('                    it.id in voiceIds && it.engineType in setOf(\n'
           '                        ReadAloudVoice.ENGINE_HTTP,\n'
           '                        ReadAloudVoice.ENGINE_CLOUD,\n'
           '                        ReadAloudVoice.ENGINE_TTS_SERVER,\n'
           '                    ) &&')
    if old not in t:
        print('  [跳补丁·未命中] ReadAloud.kt 种子过滤')
        return t
    return t.replace(old, new, 1)


def f_readaloud_delegate(t):
    if 'tts_server' in t:
        return t
    anchor = ('                httpTtsList.forEach { httpTts ->\n'
              '                    add(\n'
              '                        VoiceCatalogEntry(\n'
              '                            engineType = ReadAloudVoice.ENGINE_HTTP,\n'
              '                            engineId = httpTts.id.toString(),\n'
              '                            displayName = httpTts.name,\n'
              '                            sourceRevision = httpTts.lastUpdateTime,\n'
              '                        )\n'
              '                    )\n'
              '                }\n'
              '            },\n')
    block = ('                // [TTS-Server 移植] 并入移植层声线目录（<数据根>/_store/voices.json：标签→声线）\n'
             '                runCatching {\n'
             '                    val arr = com.github.jing332.tts.store.TtsConfigStore.loadVoices(context)\n'
             '                    for (g in 0 until arr.length()) {\n'
             '                        val list = arr.optJSONObject(g)?.optJSONArray("list") ?: continue\n'
             '                        for (i in 0 until list.length()) {\n'
             '                            val entry = list.optJSONObject(i) ?: continue\n'
             '                            val cfg = entry.optJSONObject("config") ?: continue\n'
             '                            val sr = cfg.optJSONObject("speechRule") ?: continue\n'
             '                            val tag = sr.optString("tag")\n'
             '                            val ruleId = sr.optString("tagRuleId")\n'
             '                            if (tag.isBlank() || ruleId.isBlank()) continue\n'
             '                            add(\n'
             '                                VoiceCatalogEntry(\n'
             '                                    engineType = "tts_server",\n'
             '                                    engineId = ruleId,\n'
             '                                    speakerId = tag,\n'
             '                                    displayName = entry.optString("displayName").ifBlank { sr.optString("tagName", tag) },\n'
             '                                    traitsJson = cfg.toString(),\n'
             '                                    managedBy = ReadAloudVoice.MANAGED_BY_CONFIGURED_TTS,\n'
             '                                )\n'
             '                            )\n'
             '                        }\n'
             '                    }\n'
             '                }\n')
    if anchor not in t:
        print('  [跳补丁·未命中] ReadAloudDelegate 目录并入锚点')
        return t
    t = t.replace(anchor, anchor[:-len('            },\n')] + block + '            },\n', 1)
    old2 = '            removeMissingEngineTypes = setOf(ReadAloudVoice.ENGINE_HTTP),\n'
    if old2 in t:
        t = t.replace(old2, '            removeMissingEngineTypes = setOf(ReadAloudVoice.ENGINE_HTTP, "tts_server"),\n', 1)
    else:
        print('  [跳补丁·未命中] ReadAloudDelegate removeMissingEngineTypes')
    return t


patch('app/src/main/java/io/legado/app/domain/model/readaloud/ReadAloudSpeechModels.kt',
      f_readaloud_speech_models, 'ReadAloudSpeechModels.kt（+ENGINE_TTS_SERVER）')
patch('app/src/main/java/io/legado/app/service/HttpReadAloudService.kt',
      f_http_readaloud_service, 'HttpReadAloudService.kt（引擎分派接入）')
patch('app/src/main/java/io/legado/app/model/ReadAloud.kt',
      f_readaloud_model, 'ReadAloud.kt（协调器种子过滤）')
patch('app/src/main/java/io/legado/app/ui/book/read/ReadAloudDelegate.kt',
      f_readaloud_delegate, 'ReadAloudDelegate.kt（声线目录并入）')


def f_casting_label(t):
    if 'ENGINE_TTS_SERVER' in t:
        return t
    old = ('        ReadAloudVoice.ENGINE_HTTP -> stringResource(R.string.http_tts)\n'
           '        else -> voice.engineType')
    new = ('        ReadAloudVoice.ENGINE_HTTP -> stringResource(R.string.http_tts)\n'
           '        ReadAloudVoice.ENGINE_TTS_SERVER -> "TTS Server(内嵌)"\n'
           '        else -> voice.engineType')
    if old not in t:
        print('  [跳补丁·未命中] BookVoiceCastingScreen 引擎标签')
        return t
    return t.replace(old, new, 1)


patch('app/src/main/java/io/legado/app/ui/book/readaloud/casting/BookVoiceCastingScreen.kt',
      f_casting_label, 'BookVoiceCastingScreen.kt（引擎标签）')

print('完成。改动:', changed if changed else '无')
