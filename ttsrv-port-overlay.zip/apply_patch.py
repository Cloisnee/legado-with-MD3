#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TTS-Server 移植补丁器（幂等）— 在 legado-with-MD3 的 fork 中运行
用法: python3 apply_patch.py [repo_root]

作用:
  1) settings.gradle(.kts) 注册 modules/lib-common|lib-script|lib-tts
  2) app/build.gradle.kts 增加 implementation(project(":modules:lib-tts"))
  3) App.kt 注入 HostHttp（延迟解析宿主 okHttpClient；找不到锚点时跳过且不报错）
"""
import sys, pathlib

root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else '.')
print('repo root =', root.resolve())
changed = []


def patch(rel, fn, label):
    p = root / rel
    if not p.exists():
        print(f'[跳过] {label}: 找不到 {rel}')
        return
    t = p.read_text(encoding='utf-8')
    nt = fn(t)
    if nt != t:
        p.write_text(nt, encoding='utf-8')
        changed.append(label)
        print(f'[已修改] {label}')
    else:
        print(f'[不动]  {label}（已是目标状态）')


def f_settings_groovy(t):
    mods = [":modules:lib-common", ":modules:lib-script", ":modules:lib-tts"]
    lines = [f"include '{m}'" for m in mods if f"include '{m}'" not in t]
    if not lines:
        return t
    anchor = "include ':modules:rhino'"
    if anchor in t:
        return t.replace(anchor, anchor + "\n" + "\n".join(lines), 1)
    return t.rstrip() + "\n" + "\n".join(lines) + "\n"


def f_settings_kts(t):
    mods = [":modules:lib-common", ":modules:lib-script", ":modules:lib-tts"]
    lines = [f'include("{m}")' for m in mods if f'include("{m}")' not in t]
    if not lines:
        return t
    anchor = 'include(":modules:rhino")'
    if anchor in t:
        return t.replace(anchor, anchor + "\n" + "\n".join(lines), 1)
    return t.rstrip() + "\n" + "\n".join(lines) + "\n"


def f_app_gradle(t):
    line = 'implementation(project(":modules:lib-tts"))'
    if line in t:
        return t
    anchor = 'implementation(project(":modules:rhino"))'
    if anchor in t:
        return t.replace(anchor, anchor + "\n    " + line, 1)
    anchor2 = 'androidTestImplementation(libs.room.testing)'
    if anchor2 in t:
        return t.replace(anchor2, line + "\n    " + anchor2, 1)
    raise SystemExit('[错误] app/build.gradle.kts 未找到依赖插入点')


def f_app_kt(t):
    anchor = '        AppConfigStore.init(this)'
    todo = []
    if 'HostHttp.init' not in t:
        todo.append('        com.github.jing332.compat.net.HostHttp.init { io.legado.app.help.http.okHttpClient }')
    if 'SmokeRunner' not in t:
        todo.append('        com.github.jing332.tts.debug.SmokeRunner.run(this)')
    if 'OpsRunner' not in t:
        todo.append('        com.github.jing332.tts.debug.OpsRunner.run(this)')
    if not todo:
        return t
    if anchor in t:
        block = (anchor + "\n        // [TTS-Server 移植] 网络桥注入 + 冒烟自检 + _ops 指令通道（后台运行，不阻塞启动）\n"
                 + "\n".join(todo))
        return t.replace(anchor, block, 1)
    # 兜底：若已有部分注入行，把缺失的补在最后一条注入行之后
    best_idx, best_marker = -1, None
    for m in ['com.github.jing332.tts.debug.OpsRunner.run(this)',
              'com.github.jing332.tts.debug.SmokeRunner.run(this)',
              'com.github.jing332.compat.net.HostHttp.init']:
        i = t.find(m)
        if i > best_idx:
            best_idx, best_marker = i, m
    if best_marker is not None:
        eol = t.find('\n', best_idx)
        if eol > 0:
            return t[:eol] + '\n' + '\n'.join(todo) + t[eol:]
    print('  [警告] App.kt 未找到注入锚点，跳过')
    return t


if (root / 'settings.gradle').exists():
    patch('settings.gradle', f_settings_groovy, 'settings.gradle')
elif (root / 'settings.gradle.kts').exists():
    patch('settings.gradle.kts', f_settings_kts, 'settings.gradle.kts')
else:
    print('[跳过] settings 文件不存在')

patch('app/build.gradle.kts', f_app_gradle, 'app/build.gradle.kts')
patch('app/src/main/java/io/legado/app/App.kt', f_app_kt, 'App.kt')


# ============================================================
# 阶段2 · 朗读管线接入（engineType = "tts_server"）
# ============================================================
def f_readaloud_speech_models(t):
    if 'ENGINE_TTS_SERVER' in t:
        return t
    old = '        const val ENGINE_CLOUD = "cloud_tts"\n'
    if old not in t:
        print('  [跳补丁·未命中] ReadAloudSpeechModels 常量锚点')
        return t
    return t.replace(old, old + '        const val ENGINE_TTS_SERVER = "tts_server"\n', 1)


def f_http_readaloud_service(t):
    if 'TtsServerSynthesizer' in t:
        return t
    pairs = [
        # 1) 合成器声明
        (
            '    private val cloudTtsAudioSynthesizer by lazy {\n'
            '        CloudTtsAudioSynthesizer(get(CloudTtsEngineGateway::class.java))\n'
            '    }\n',
            '    private val cloudTtsAudioSynthesizer by lazy {\n'
            '        CloudTtsAudioSynthesizer(get(CloudTtsEngineGateway::class.java))\n'
            '    }\n'
            '    // [TTS-Server 移植] 内嵌引擎合成器（engineType = tts_server）\n'
            '    private val ttsServerSynthesizer by lazy {\n'
            '        com.github.jing332.tts.readaloud.TtsServerSynthesizer(this)\n'
            '    }\n',
        ),
        # 2) 主合成 when：CLOUD 分支前插入
        (
            '                                ReadAloudVoice.ENGINE_CLOUD -> {\n'
            '                                    val output = getSpeakFileAsMd5(fileName)\n'
            '                                    if (!cloudTtsAudioSynthesizer.synthesize(',
            '                                ReadAloudVoice.ENGINE_TTS_SERVER -> {\n'
            '                                    val output = getSpeakFileAsMd5(fileName)\n'
            '                                    if (!ttsServerSynthesizer.synthesize(\n'
            '                                            routedVoice.engineId,\n'
            '                                            routedVoice.speakerId,\n'
            '                                            speakText,\n'
            '                                            output,\n'
            '                                        )\n'
            '                                    ) {\n'
            '                                        createSilentSound(fileName)\n'
            '                                    }\n'
            '                                }\n'
            '\n'
            '                                ReadAloudVoice.ENGINE_CLOUD -> {\n'
            '                                    val output = getSpeakFileAsMd5(fileName)\n'
            '                                    if (!cloudTtsAudioSynthesizer.synthesize(',
        ),
        # 3) 单 cue 合成 when：CLOUD 分支前插入
        (
            '                ReadAloudVoice.ENGINE_CLOUD -> {\n'
            '                    val output = getSpeakFileAsMd5(fileName)\n'
            '                    cloudTtsAudioSynthesizer.synthesize(',
            '                ReadAloudVoice.ENGINE_TTS_SERVER -> {\n'
            '                    val output = getSpeakFileAsMd5(fileName)\n'
            '                    ttsServerSynthesizer.synthesize(\n'
            '                        routedVoice.engineId,\n'
            '                        routedVoice.speakerId,\n'
            '                        speakText,\n'
            '                        output,\n'
            '                    )\n'
            '                }\n'
            '\n'
            '                ReadAloudVoice.ENGINE_CLOUD -> {\n'
            '                    val output = getSpeakFileAsMd5(fileName)\n'
            '                    cloudTtsAudioSynthesizer.synthesize(',
        ),
        # 4) 预下载条件
        (
            '                    if (routedVoice.engineType == ReadAloudVoice.ENGINE_CLOUD) {',
            '                    if (routedVoice.engineType == ReadAloudVoice.ENGINE_CLOUD ||\n'
            '                        routedVoice.engineType == ReadAloudVoice.ENGINE_TTS_SERVER) {',
        ),
        # 5) sourceKeyForCue：ELSE 前插入分支
        (
            '            else -> {\n'
            '                val itemHttpTts = routedVoice.engineId.toLongOrNull()\n'
            '                    ?.let(appDb.httpTTSDao::get) ?: httpTts\n'
            '                itemHttpTts.url\n'
            '            }',
            '            ReadAloudVoice.ENGINE_TTS_SERVER ->\n'
            '                "tts_server:${routedVoice.id}:${routedVoice.revision}:" +\n'
            '                        "${routedVoice.engineId}:${routedVoice.speakerId}:$cueEmotion"\n'
            '\n'
            '            else -> {\n'
            '                val itemHttpTts = routedVoice.engineId.toLongOrNull()\n'
            '                    ?.let(appDb.httpTTSDao::get) ?: httpTts\n'
            '                itemHttpTts.url\n'
            '            }',
        ),
        # 6) voiceForCue 支持集
        (
            '            supportedEngineTypes = setOf(\n'
            '                ReadAloudVoice.ENGINE_HTTP,\n'
            '                ReadAloudVoice.ENGINE_SYSTEM,\n'
            '                ReadAloudVoice.ENGINE_CLOUD,\n'
            '            ),',
            '            supportedEngineTypes = setOf(\n'
            '                ReadAloudVoice.ENGINE_HTTP,\n'
            '                ReadAloudVoice.ENGINE_SYSTEM,\n'
            '                ReadAloudVoice.ENGINE_CLOUD,\n'
            '                ReadAloudVoice.ENGINE_TTS_SERVER,\n'
            '            ),',
        ),
        # 7) hasFileSynthesisCue 集合
        (
            '            setOf(\n'
            '                ReadAloudVoice.ENGINE_SYSTEM,\n'
            '                ReadAloudVoice.ENGINE_CLOUD,\n'
            '            )',
            '            setOf(\n'
            '                ReadAloudVoice.ENGINE_SYSTEM,\n'
            '                ReadAloudVoice.ENGINE_CLOUD,\n'
            '                ReadAloudVoice.ENGINE_TTS_SERVER,\n'
            '            )',
        ),
    ]
    for old, new in pairs:
        if old not in t:
            print('  [跳补丁·未命中] HttpReadAloudService: ' + repr(old[:70]))
            continue
        t = t.replace(old, new, 1)
    return t


def f_readaloud_model(t):
    if 'ENGINE_TTS_SERVER' in t:
        return t
    old = ('                    it.id in voiceIds && it.engineType in setOf(\n'
           '                        ReadAloudVoice.ENGINE_HTTP,\n'
           '                        ReadAloudVoice.ENGINE_CLOUD,\n'
           '                    ) &&')
    new = ('                    it.id in voiceIds && it.engineType in setOf(\n'
           '                        ReadAloudVoice.ENGINE_HTTP,\n'
           '                        ReadAloudVoice.ENGINE_CLOUD,\n'
           '                        ReadAloudVoice.ENGINE_TTS_SERVER,\n'
           '                    ) &&')
    if old not in t:
        print('  [跳补丁·未命中] ReadAloud.kt 种子过滤')
        return t
    return t.replace(old, new, 1)


def f_readaloud_delegate(t):
    if 'tts_server' in t:
        return t
    anchor = ('                httpTtsList.forEach { httpTts ->\n'
              '                    add(\n'
              '                        VoiceCatalogEntry(\n'
              '                            engineType = ReadAloudVoice.ENGINE_HTTP,\n'
              '                            engineId = httpTts.id.toString(),\n'
              '                            displayName = httpTts.name,\n'
              '                            sourceRevision = httpTts.lastUpdateTime,\n'
              '                        )\n'
              '                    )\n'
              '                }\n'
              '            },\n')
    block = ('                // [TTS-Server 移植] 并入移植层声线目录（<数据根>/_store/voices.json：标签→声线）\n'
             '                runCatching {\n'
             '                    val arr = com.github.jing332.tts.store.TtsConfigStore.loadVoices(context)\n'
             '                    for (g in 0 until arr.length()) {\n'
             '                        val list = arr.optJSONObject(g)?.optJSONArray("list") ?: continue\n'
             '                        for (i in 0 until list.length()) {\n'
             '                            val entry = list.optJSONObject(i) ?: continue\n'
             '                            val cfg = entry.optJSONObject("config") ?: continue\n'
             '                            val sr = cfg.optJSONObject("speechRule") ?: continue\n'
             '                            val tag = sr.optString("tag")\n'
             '                            val ruleId = sr.optString("tagRuleId")\n'
             '                            if (tag.isBlank() || ruleId.isBlank()) continue\n'
             '                            add(\n'
             '                                VoiceCatalogEntry(\n'
             '                                    engineType = "tts_server",\n'
             '                                    engineId = ruleId,\n'
             '                                    speakerId = tag,\n'
             '                                    displayName = entry.optString("displayName").ifBlank { sr.optString("tagName", tag) },\n'
             '                                    traitsJson = cfg.toString(),\n'
             '                                    managedBy = ReadAloudVoice.MANAGED_BY_CONFIGURED_TTS,\n'
             '                                )\n'
             '                            )\n'
             '                        }\n'
             '                    }\n'
             '                }\n')
    if anchor not in t:
        print('  [跳补丁·未命中] ReadAloudDelegate 目录并入锚点')
        return t
    t = t.replace(anchor, anchor[:-len('            },\n')] + block + '            },\n', 1)
    old2 = '            removeMissingEngineTypes = setOf(ReadAloudVoice.ENGINE_HTTP),\n'
    if old2 in t:
        t = t.replace(old2, '            removeMissingEngineTypes = setOf(ReadAloudVoice.ENGINE_HTTP, "tts_server"),\n', 1)
    else:
        print('  [跳补丁·未命中] ReadAloudDelegate removeMissingEngineTypes')
    return t


patch('app/src/main/java/io/legado/app/domain/model/readaloud/ReadAloudSpeechModels.kt',
      f_readaloud_speech_models, 'ReadAloudSpeechModels.kt（+ENGINE_TTS_SERVER）')
patch('app/src/main/java/io/legado/app/service/HttpReadAloudService.kt',
      f_http_readaloud_service, 'HttpReadAloudService.kt（引擎分派接入）')
patch('app/src/main/java/io/legado/app/model/ReadAloud.kt',
      f_readaloud_model, 'ReadAloud.kt（协调器种子过滤）')
patch('app/src/main/java/io/legado/app/ui/book/read/ReadAloudDelegate.kt',
      f_readaloud_delegate, 'ReadAloudDelegate.kt（声线目录并入）')


def f_casting_label(t):
    if 'ENGINE_TTS_SERVER' in t:
        return t
    old = ('        ReadAloudVoice.ENGINE_HTTP -> stringResource(R.string.http_tts)\n'
           '        else -> voice.engineType')
    new = ('        ReadAloudVoice.ENGINE_HTTP -> stringResource(R.string.http_tts)\n'
           '        ReadAloudVoice.ENGINE_TTS_SERVER -> "TTS Server(内嵌)"\n'
           '        else -> voice.engineType')
    if old not in t:
        print('  [跳补丁·未命中] BookVoiceCastingScreen 引擎标签')
        return t
    return t.replace(old, new, 1)


patch('app/src/main/java/io/legado/app/ui/book/readaloud/casting/BookVoiceCastingScreen.kt',
      f_casting_label, 'BookVoiceCastingScreen.kt（引擎标签）')


# ============================================================
# 阶段2-UI1 · 管理中心接入（我的入口 + 路由 + 内置引擎选择）
# ============================================================
def f_my_screen(t):
    if 'OpenTtsServerCenter' in t:
        return t
    imp_anchor = 'import androidx.compose.material.icons.filled.OpenInBrowser\n'
    if imp_anchor in t and 'import androidx.compose.material.icons.filled.RecordVoiceOver\n' not in t:
        t = t.replace(
            imp_anchor,
            imp_anchor + 'import androidx.compose.material.icons.filled.RecordVoiceOver\n', 1)
    group_anchor = ('            SplicedColumnGroup(\n'
                    '                title = stringResource(R.string.other)\n'
                    '            ) {\n')
    block = ('            SplicedColumnGroup(\n'
             '                title = "朗读"\n'
             '            ) {\n'
             '                ClickableSettingItem(\n'
             '                    title = stringResource(R.string.read_aloud_engines_and_voices),\n'
             '                    description = "声线插件 · 配置列表 · 内置引擎",\n'
             '                    imageVector = Icons.Default.RecordVoiceOver,\n'
             '                    onClick = { onNavigate(PrefClickEvent.OpenTtsServerCenter) }\n'
             '                )\n'
             '            }\n'
             '\n')
    if group_anchor not in t:
        print('  [跳补丁·未命中] MyScreen 分组锚点')
        return t
    return t.replace(group_anchor, block + group_anchor, 1)


def f_my_viewmodel(t):
    if 'OpenTtsServerCenter' in t:
        return t
    old = '    object OpenBookCacheManage : PrefClickEvent()\n'
    if old not in t:
        print('  [跳补丁·未命中] MyViewModel 事件锚点')
        return t
    return t.replace(old, old + '    object OpenTtsServerCenter : PrefClickEvent()\n', 1)


def f_main_screen(t):
    if 'onNavigateToTtsServerCenter' in t:
        return t
    sig_old = '    onNavigateToBookCacheManage: () -> Unit,\n'
    if sig_old not in t:
        print('  [跳补丁·未命中] MainScreen 签名锚点')
        return t
    t = t.replace(sig_old, sig_old + '    onNavigateToTtsServerCenter: () -> Unit,\n', 1)
    when_old = 'PrefClickEvent.OpenBookCacheManage -> onNavigateToBookCacheManage()\n'
    if when_old not in t:
        print('  [跳补丁·未命中] MainScreen when 锚点')
        return t
    idx = t.find(when_old)
    indent = ''
    j = idx - 1
    while j >= 0 and t[j] == ' ':
        indent = ' ' + indent
        j -= 1
    return t.replace(
        when_old,
        when_old + indent + 'PrefClickEvent.OpenTtsServerCenter -> onNavigateToTtsServerCenter()\n',
        1)


def f_main_nav_graph(t):
    if 'MainRouteTtsServerCenter' in t:
        return t
    cb_old = ('            onNavigateToBookCacheManage = {\n'
              '                onNavigateToRoute(MainRouteBookCacheManage)\n'
              '            },\n')
    if cb_old not in t:
        print('  [跳补丁·未命中] MainNavGraph 回调锚点')
        return t
    t = t.replace(cb_old, cb_old + ('            onNavigateToTtsServerCenter = {\n'
                                    '                onNavigateToRoute(MainRouteTtsServerCenter)\n'
                                    '            },\n'), 1)
    entry_old = ('    entry<MainRouteTtsCache> {\n'
                 '        TtsCacheRouteScreen(\n'
                 '            onBackClick = { onNavigateBack() },\n'
                 '        )\n'
                 '    }\n')
    if entry_old not in t:
        print('  [跳补丁·未命中] MainNavGraph entry 锚点')
        return t
    t = t.replace(entry_old, entry_old + ('\n    entry<MainRouteTtsServerCenter> {\n'
                                          '        io.legado.app.ui.ttssrv.TtsServerCenterRouteScreen(\n'
                                          '            onBackClick = { onNavigateBack() },\n'
                                          '        )\n'
                                          '    }\n'), 1)
    return t


def f_main_nav_key(t):
    if 'MainRouteTtsServerCenter' in t:
        return t
    old = 'data object MainRouteTtsCache : MainRoute\n'
    if old not in t:
        print('  [跳补丁·未命中] MainNavKey 锚点')
        return t
    return t.replace(
        old, old + '\n@Serializable\ndata object MainRouteTtsServerCenter : MainRoute\n', 1)


def f_readaloud_selection(t):
    if 'it.engineType == ReadAloudVoice.ENGINE_TTS_SERVER }' in t:
        return t
    old = '?.takeIf { it.engineType == ReadAloudVoice.ENGINE_CLOUD }'
    if old not in t:
        print('  [跳补丁·未命中] ReadAloud.getReadAloudClass 选择锚点')
        return t
    return t.replace(
        old,
        '?.takeIf { it.engineType == ReadAloudVoice.ENGINE_CLOUD || it.engineType == ReadAloudVoice.ENGINE_TTS_SERVER }',
        1)


patch('app/src/main/java/io/legado/app/ui/main/my/MyScreen.kt', f_my_screen,
      'MyScreen.kt（朗读分组入口）')
patch('app/src/main/java/io/legado/app/ui/main/my/MyViewModel.kt', f_my_viewmodel,
      'MyViewModel.kt（事件）')
patch('app/src/main/java/io/legado/app/ui/main/MainScreen.kt', f_main_screen,
      'MainScreen.kt（回调装配）')
patch('app/src/main/java/io/legado/app/ui/main/MainNavGraph.kt', f_main_nav_graph,
      'MainNavGraph.kt（路由装配）')
patch('app/src/main/java/io/legado/app/ui/main/MainNavKey.kt', f_main_nav_key,
      'MainNavKey.kt（路由）')
patch('app/src/main/java/io/legado/app/model/ReadAloud.kt', f_readaloud_selection,
      'ReadAloud.kt（内置引擎选择接入）')


def f_main_navigator(t):
    if 'MainRouteTtsServerCenter' in t:
        return t
    old = '            MainRouteBookCacheManage,\n'
    if old not in t:
        print('  [跳补丁·未命中] MainNavigator 分支锚点')
        return t
    return t.replace(old, old + '            MainRouteTtsServerCenter,\n', 1)


patch('app/src/main/java/io/legado/app/ui/main/MainNavigator.kt', f_main_navigator,
      'MainNavigator.kt（路由分发分支）')


# ============================================================
# UI-2B（第一批）：朗读日志化 + 朗读音频缓存页 + 我的入口
# ============================================================
def f_my_screen2(t):
    if 'OpenReadAloudLogs' in t:
        return t
    old = ('                    onClick = { onNavigate(PrefClickEvent.OpenTtsServerCenter) }\n'
           '                )\n'
           '            }\n')
    if old not in t:
        print('  [跳补丁·未命中] MyScreen2')
        return t
    new = ('                    onClick = { onNavigate(PrefClickEvent.OpenTtsServerCenter) }\n'
           '                )\n'
           '                ClickableSettingItem(\n'
           '                    title = stringResource(R.string.tts_cache_manage),\n'
           '                    description = "查看朗读 / 合成操作日志",\n'
           '                    imageVector = Icons.Default.History,\n'
           '                    onClick = { onNavigate(PrefClickEvent.OpenReadAloudLogs) }\n'
           '                )\n'
           '            }\n')
    return t.replace(old, new, 1)


def f_my_viewmodel2(t):
    if 'OpenReadAloudLogs' in t:
        return t
    old = '    object OpenTtsServerCenter : PrefClickEvent()\n'
    if old not in t:
        print('  [跳补丁·未命中] MyViewModel2')
        return t
    return t.replace(old, old + '    object OpenReadAloudLogs : PrefClickEvent()\n', 1)


def f_main_screen2(t):
    if 'onNavigateToReadAloudLogs' in t:
        return t
    sig_old = '    onNavigateToTtsServerCenter: () -> Unit,\n'
    if sig_old not in t:
        print('  [跳补丁·未命中] MainScreen2 签名')
        return t
    t = t.replace(sig_old, sig_old + '    onNavigateToReadAloudLogs: () -> Unit,\n', 1)
    old = 'PrefClickEvent.OpenTtsServerCenter -> onNavigateToTtsServerCenter()\n'
    if old not in t:
        print('  [跳补丁·未命中] MainScreen2 when')
        return t
    idx = t.find(old)
    indent = ''
    j = idx - 1
    while j >= 0 and t[j] == ' ':
        indent = ' ' + indent
        j -= 1
    return t.replace(
        old,
        old + indent + 'PrefClickEvent.OpenReadAloudLogs -> onNavigateToReadAloudLogs()\n',
        1)


def f_main_nav_key2(t):
    if 'MainRouteTtsAudioCache' in t:
        return t
    old = 'data object MainRouteTtsServerCenter : MainRoute\n'
    if old not in t:
        print('  [跳补丁·未命中] NavKey2')
        return t
    return t.replace(old, old + '\n@Serializable\ndata object MainRouteTtsAudioCache : MainRoute\n', 1)


def f_main_nav_graph2(t):
    if 'MainRouteTtsAudioCache' in t:
        return t
    old = ('            onNavigateToTtsServerCenter = {\n'
           '                onNavigateToRoute(MainRouteTtsServerCenter)\n'
           '            },\n')
    if old in t:
        t = t.replace(old, old + ('            onNavigateToReadAloudLogs = {\n'
                                  '                onNavigateToRoute(MainRouteTtsCache)\n'
                                  '            },\n'), 1)
    else:
        print('  [跳补丁·未命中] NavGraph2 MainScreen 回调')
    old2 = ('    entry<MainRouteTtsServerCenter> {\n'
            '        io.legado.app.ui.ttssrv.TtsServerCenterRouteScreen(\n'
            '            onBackClick = { onNavigateBack() },\n'
            '        )\n'
            '    }\n')
    if old2 in t:
        t = t.replace(old2, old2 + ('\n    entry<MainRouteTtsAudioCache> {\n'
                                    '        io.legado.app.ui.ttssrv.TtsAudioCacheRouteScreen(\n'
                                    '            onBackClick = { onNavigateBack() },\n'
                                    '        )\n'
                                    '    }\n'), 1)
    else:
        print('  [跳补丁·未命中] NavGraph2 音频缓存 entry')
    old3 = ('    entry<MainRouteBookCacheManage> {\n'
            '        BookCacheManageRouteScreen(\n'
            '            onBackClick = { onNavigateBack() }\n'
            '        )\n'
            '    }\n')
    if old3 in t:
        t = t.replace(old3, ('    entry<MainRouteBookCacheManage> {\n'
                             '        BookCacheManageRouteScreen(\n'
                             '            onBackClick = { onNavigateBack() },\n'
                             '            onOpenTtsAudioCache = { onNavigateToRoute(MainRouteTtsAudioCache) },\n'
                             '        )\n'
                             '    }\n'), 1)
    else:
        print('  [跳补丁·未命中] NavGraph2 BookCacheManage entry')
    return t


def f_main_navigator2(t):
    if 'MainRouteTtsAudioCache' in t:
        return t
    o1 = '            MainRouteTtsServerCenter,\n'
    if o1 in t:
        t = t.replace(o1, o1 + '            MainRouteTtsAudioCache,\n', 1)
    else:
        print('  [跳补丁·未命中] Navigator2 路由列表')
    o2 = ('                if (\n'
          '                    currentRoute == MainRouteHome ||\n'
          '                    currentRoute is MainRouteBookInfo\n'
          '                ) {\n'
          '                    backStack.add(route)\n'
          '                } else {\n'
          '                    backStack.clear()\n'
          '                    backStack.add(MainRouteHome)\n'
          '                    backStack.add(route)\n'
          '                }\n'
          '            }\n'
          '\n'
          '            is MainRouteAudioPlay -> {\n')
    if o2 in t:
        n2 = ('                if (\n'
              '                    currentRoute == MainRouteHome ||\n'
              '                    currentRoute == MainRouteBookCacheManage ||\n'
              '                    currentRoute is MainRouteBookInfo\n'
              '                ) {\n'
              '                    backStack.add(route)\n'
              '                } else {\n'
              '                    backStack.clear()\n'
              '                    backStack.add(MainRouteHome)\n'
              '                    backStack.add(route)\n'
              '                }\n'
              '            }\n'
              '\n'
              '            is MainRouteAudioPlay -> {\n')
        t = t.replace(o2, n2, 1)
    else:
        print('  [跳补丁·未命中] Navigator2 条件')
    return t


def f_tts_cache_screen(t):
    if 'R.string.tts_cache_tab_files' not in t and 'tts_cache_tab_logs' in t:
        return t
    old1 = ('                    AppTabRow(\n'
            '                        tabTitles = listOf(\n'
            '                            stringResource(R.string.tts_cache_tab_files),\n'
            '                            stringResource(R.string.tts_cache_tab_logs),\n'
            '                        ),\n'
            '                        selectedTabIndex = state.selectedTab.ordinal,\n'
            '                        onTabSelected = { onIntent(TtsCacheIntent.SelectTab(TtsCacheTab.entries[it])) },\n'
            '                        isScrollable = false,\n'
            '                    )\n')
    new1 = ('                    AppTabRow(\n'
            '                        tabTitles = listOf(\n'
            '                            stringResource(R.string.tts_cache_tab_logs),\n'
            '                        ),\n'
            '                        selectedTabIndex = 0,\n'
            '                        onTabSelected = {},\n'
            '                        isScrollable = false,\n'
            '                    )\n')
    if old1 not in t:
        print('  [跳补丁·未命中] TtsCacheScreen tabs')
        return t
    t = t.replace(old1, new1, 1)
    o2 = '            if (state.selectedTab == TtsCacheTab.Files && state.files.isNotEmpty()) {'
    if o2 in t:
        t = t.replace(o2, '            if (false) {', 1)
    else:
        print('  [跳补丁·未命中] TtsCacheScreen FAB')
    o3 = '            if (state.selectedTab == TtsCacheTab.Files) {'
    if o3 in t:
        t = t.replace(o3, '            if (false) {', 1)
    else:
        print('  [跳补丁·未命中] TtsCacheScreen content')
    return t


def f_book_cache_manage(t):
    if 'onOpenTtsAudioCache' in t:
        return t
    a1 = 'import io.legado.app.ui.widget.components.AppScaffold\n'
    if 'import io.legado.app.ui.widget.components.SplicedColumnGroup\n' not in t and a1 in t:
        t = t.replace(a1, a1 + 'import io.legado.app.ui.widget.components.SplicedColumnGroup\n', 1)
    a2 = 'import io.legado.app.ui.widget.components.alert.AppAlertDialog\n'
    if 'import io.legado.app.ui.widget.components.settingItem.ClickableSettingItem\n' not in t and a2 in t:
        t = t.replace(a2, a2 + 'import io.legado.app.ui.widget.components.settingItem.ClickableSettingItem\n', 1)

    o = ('fun BookCacheManageRouteScreen(\n'
         '    onBackClick: () -> Unit,\n'
         '    viewModel: BookCacheManageViewModel = koinViewModel()\n'
         ') {\n')
    n = ('fun BookCacheManageRouteScreen(\n'
         '    onBackClick: () -> Unit,\n'
         '    onOpenTtsAudioCache: () -> Unit = {},\n'
         '    viewModel: BookCacheManageViewModel = koinViewModel()\n'
         ') {\n')
    if o in t:
        t = t.replace(o, n, 1)
    else:
        print('  [跳补丁·未命中] BookCacheManage RouteScreen 签名')

    o = ('    BookCacheManageScreen(\n'
         '        state = state,\n'
         '        onBackClick = onBackClick,\n'
         '        onIntent = viewModel::onIntent\n'
         '    )')
    n = ('    BookCacheManageScreen(\n'
         '        state = state,\n'
         '        onBackClick = onBackClick,\n'
         '        onIntent = viewModel::onIntent,\n'
         '        onOpenTtsAudioCache = onOpenTtsAudioCache,\n'
         '    )')
    if o in t:
        t = t.replace(o, n, 1)
    else:
        print('  [跳补丁·未命中] BookCacheManage 调用')

    o = ('private fun BookCacheManageScreen(\n'
         '    state: BookCacheManageUiState,\n'
         '    onBackClick: () -> Unit,\n'
         '    onIntent: (BookCacheManageIntent) -> Unit,\n'
         ') {')
    n = ('private fun BookCacheManageScreen(\n'
         '    state: BookCacheManageUiState,\n'
         '    onBackClick: () -> Unit,\n'
         '    onIntent: (BookCacheManageIntent) -> Unit,\n'
         '    onOpenTtsAudioCache: () -> Unit = {},\n'
         ') {')
    if o in t:
        t = t.replace(o, n, 1)
    else:
        print('  [跳补丁·未命中] BookCacheManage 私有签名')

    o = ('                verticalArrangement = Arrangement.spacedBy(8.dp)\n'
         '            ) {\n'
         '                cacheSection(\n')
    n = ('                verticalArrangement = Arrangement.spacedBy(8.dp)\n'
         '            ) {\n'
         '                item(key = "tts_audio_cache_entry") {\n'
         '                    SplicedColumnGroup {\n'
         '                        ClickableSettingItem(\n'
         '                            title = "朗读音频缓存",\n'
         '                            description = "管理 TTS 合成产生的音频文件",\n'
         '                            onClick = { onOpenTtsAudioCache() }\n'
         '                        )\n'
         '                    }\n'
         '                }\n'
         '                cacheSection(\n')
    if o in t:
        t = t.replace(o, n, 1)
    else:
        print('  [跳补丁·未命中] BookCacheManage 列表入口')
    return t


def f_strings_cache(t):
    if 'tts_cache_manage">朗读日志<' in t or 'tts_cache_manage">Read-aloud Logs<' in t:
        return t
    if 'tts_cache_manage">朗读缓存<' in t:
        t = t.replace('tts_cache_manage">朗读缓存<', 'tts_cache_manage">朗读日志<', 1)
        t = t.replace('tts_cache_manage_summary">查看和管理朗读音频缓存文件<',
                      'tts_cache_manage_summary">查看朗读 / 合成操作日志<', 1)
    if 'tts_cache_manage">TTS Cache<' in t:
        t = t.replace('tts_cache_manage">TTS Cache<', 'tts_cache_manage">Read-aloud Logs<', 1)
        t = t.replace('tts_cache_manage_summary">View and manage cached TTS audio files<',
                      'tts_cache_manage_summary">View read-aloud / synthesis operation logs<', 1)
    return t


patch('app/src/main/java/io/legado/app/ui/main/my/MyScreen.kt', f_my_screen2,
      'MyScreen.kt（+朗读日志入口）')
patch('app/src/main/java/io/legado/app/ui/main/my/MyViewModel.kt', f_my_viewmodel2,
      'MyViewModel.kt（+朗读日志事件）')
patch('app/src/main/java/io/legado/app/ui/main/MainScreen.kt', f_main_screen2,
      'MainScreen.kt（+朗读日志回调）')
patch('app/src/main/java/io/legado/app/ui/main/MainNavGraph.kt', f_main_nav_graph2,
      'MainNavGraph.kt（+音频缓存路由/回调）')
patch('app/src/main/java/io/legado/app/ui/main/MainNavKey.kt', f_main_nav_key2,
      'MainNavKey.kt（+音频缓存路由）')
patch('app/src/main/java/io/legado/app/ui/main/MainNavigator.kt', f_main_navigator2,
      'MainNavigator.kt（+音频缓存分发）')
patch('app/src/main/java/io/legado/app/ui/book/readaloud/cache/TtsCacheScreen.kt', f_tts_cache_screen,
      'TtsCacheScreen.kt（朗读日志化）')
patch('app/src/main/java/io/legado/app/ui/book/cache/manage/BookCacheManageScreen.kt', f_book_cache_manage,
      'BookCacheManageScreen.kt（+朗读音频缓存入口）')
patch('app/src/main/res/values/strings.xml', f_strings_cache, 'strings.xml（朗读日志）')
patch('app/src/main/res/values-zh-rCN/strings.xml', f_strings_cache, 'strings-zh-rCN（朗读日志）')


# ============================================================
# UI-2B（第二批）：音频缓存书籍/章节元数据 + 日志页去标题
# ============================================================
def f_service_cache_meta(t):
    if 'writeCacheMetaEntry' in t:
        return t
    marker = '    private fun buildIndexJson(index: Map<String, String>): String = buildString {'
    if marker not in t:
        print('  [跳补丁·未命中] Service meta 函数锚点')
        return t
    meta_fn = r'''    /** [TTS-Server 移植] 追加朗读音频缓存元数据（jsonl：文件名 -> 书 / 章节 / 文本） */
    private fun writeCacheMetaEntry(fileName: String, text: String, chapterTitle: String) {
        try {
            val baseDir = externalCacheDir ?: cacheDir
            val dir = File(baseDir, "httpTTS").apply { mkdirs() }
            val metaFile = File(dir, "tts_cache_meta.jsonl")
            val book = ReadBook.book
            val shortText = if (text.length > 200) text.substring(0, 200) + "…" else text
            fun esc(s: String): String = s
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
            val line = "{\"f\":\"" + esc(fileName) + "\",\"b\":\"" + esc(book?.name.orEmpty()) +
                    "\",\"u\":\"" + esc(book?.bookUrl.orEmpty()) + "\",\"c\":\"" + esc(chapterTitle) +
                    "\",\"t\":\"" + esc(shortText) + "\"}"
            metaFile.appendText(line + "\n")
            runCatching {
                val lines = metaFile.readLines()
                if (lines.size > 4000) {
                    metaFile.writeText(lines.takeLast(4000).joinToString("\n", postfix = "\n"))
                }
            }
        } catch (_: Exception) {
        }
    }

'''
    t = t.replace(marker, meta_fn + marker, 1)
    # 调用点 1：主播放合成
    o1 = ('                    if (speakText.isNotEmpty() && hasSpeakFile(fileName)) {\n'
          '                        writeTextIndexEntry(fileName, speakText)\n'
          '                    }\n')
    n1 = ('                    if (speakText.isNotEmpty() && hasSpeakFile(fileName)) {\n'
          '                        writeTextIndexEntry(fileName, speakText)\n'
          '                        writeCacheMetaEntry(\n'
          '                            fileName, speakText, ReadBook.book?.durChapterTitle.orEmpty()\n'
          '                        )\n'
          '                    }\n')
    if o1 in t:
        t = t.replace(o1, n1, 1)
    else:
        print('  [跳补丁·未命中] Service meta 调用点1')
    # 调用点 2：预合成单 cue
    o2 = ('        if (success && speakText.isNotEmpty()) {\n'
          '            writeTextIndexEntry(fileName, speakText)\n'
          '        }\n')
    n2 = ('        if (success && speakText.isNotEmpty()) {\n'
          '            writeTextIndexEntry(fileName, speakText)\n'
          '            writeCacheMetaEntry(fileName, speakText, chapterTitle)\n'
          '        }\n')
    if o2 in t:
        t = t.replace(o2, n2, 1)
    else:
        print('  [跳补丁·未命中] Service meta 调用点2')
    return t


def f_tts_cache_screen2(t):
    if 'tts_cache_tab_logs' not in t:
        return t
    old = ('                bottomContent = {\n'
           '                    AppTabRow(\n'
           '                        tabTitles = listOf(\n'
           '                            stringResource(R.string.tts_cache_tab_logs),\n'
           '                        ),\n'
           '                        selectedTabIndex = 0,\n'
           '                        onTabSelected = {},\n'
           '                        isScrollable = false,\n'
           '                    )\n'
           '                }\n')
    if old not in t:
        print('  [跳补丁·未命中] TtsCacheScreen2 去标题')
        return t
    return t.replace(old, '', 1)


patch('app/src/main/java/io/legado/app/service/HttpReadAloudService.kt', f_service_cache_meta,
      'HttpReadAloudService.kt（+缓存元数据）')
patch('app/src/main/java/io/legado/app/ui/book/readaloud/cache/TtsCacheScreen.kt', f_tts_cache_screen2,
      'TtsCacheScreen.kt（去标题栏）')


# ============================================================
# UI-2B（主菜）：朗读设置页 + 阅读内瘦身
# ============================================================
def f_my_screen3(t):
    if 'OpenReadAloudSettings' in t:
        return t
    old = ('                    onClick = { onNavigate(PrefClickEvent.OpenTtsServerCenter) }\n'
           '                )\n')
    if old not in t:
        print('  [跳补丁·未命中] MyScreen3')
        return t
    new = old + ('                ClickableSettingItem(\n'
                 '                    title = stringResource(R.string.aloud_config),\n'
                 '                    description = "界面 / 播放行为 / 语音与分析 / 性能",\n'
                 '                    imageVector = Icons.Default.Settings,\n'
                 '                    onClick = { onNavigate(PrefClickEvent.OpenReadAloudSettings) }\n'
                 '                )\n')
    return t.replace(old, new, 1)


def f_my_viewmodel3(t):
    if 'OpenReadAloudSettings' in t:
        return t
    old = '    object OpenReadAloudLogs : PrefClickEvent()\n'
    if old not in t:
        print('  [跳补丁·未命中] MyViewModel3')
        return t
    return t.replace(old, old + '    object OpenReadAloudSettings : PrefClickEvent()\n', 1)


def f_main_screen3(t):
    if 'onNavigateToReadAloudSettings' in t:
        return t
    sig_old = '    onNavigateToReadAloudLogs: () -> Unit,\n'
    if sig_old not in t:
        print('  [跳补丁·未命中] MainScreen3 签名')
        return t
    t = t.replace(sig_old, sig_old + '    onNavigateToReadAloudSettings: () -> Unit,\n', 1)
    old = 'PrefClickEvent.OpenReadAloudLogs -> onNavigateToReadAloudLogs()\n'
    if old not in t:
        print('  [跳补丁·未命中] MainScreen3 when')
        return t
    idx = t.find(old)
    indent = ''
    j = idx - 1
    while j >= 0 and t[j] == ' ':
        indent = ' ' + indent
        j -= 1
    return t.replace(
        old,
        old + indent + 'PrefClickEvent.OpenReadAloudSettings -> onNavigateToReadAloudSettings()\n',
        1)


def f_main_nav_key3(t):
    if 'MainRouteReadAloudSettings' in t:
        return t
    old = 'data object MainRouteTtsAudioCache : MainRoute\n'
    if old not in t:
        print('  [跳补丁·未命中] NavKey3')
        return t
    return t.replace(
        old, old + '\n@Serializable\ndata object MainRouteReadAloudSettings : MainRoute\n', 1)


def f_main_nav_graph3(t):
    if 'MainRouteReadAloudSettings' in t:
        return t
    old = ('            onNavigateToReadAloudLogs = {\n'
           '                onNavigateToRoute(MainRouteTtsCache)\n'
           '            },\n')
    if old in t:
        t = t.replace(old, old + ('            onNavigateToReadAloudSettings = {\n'
                                  '                onNavigateToRoute(MainRouteReadAloudSettings)\n'
                                  '            },\n'), 1)
    else:
        print('  [跳补丁·未命中] NavGraph3 回调')
    old2 = ('    entry<MainRouteTtsAudioCache> {\n'
            '        io.legado.app.ui.ttssrv.TtsAudioCacheRouteScreen(\n'
            '            onBackClick = { onNavigateBack() },\n'
            '        )\n'
            '    }\n')
    if old2 in t:
        t = t.replace(old2, old2 + ('\n    entry<MainRouteReadAloudSettings> {\n'
                                    '        io.legado.app.ui.ttssrv.ReadAloudSettingsRouteScreen(\n'
                                    '            onBackClick = { onNavigateBack() },\n'
                                    '            onOpenCasting = { url ->\n'
                                    '                onNavigateToRoute(MainRouteBookVoiceCasting(url))\n'
                                    '            },\n'
                                    '        )\n'
                                    '    }\n'), 1)
    else:
        print('  [跳补丁·未命中] NavGraph3 entry')
    return t


def f_main_navigator3(t):
    if 'MainRouteReadAloudSettings' in t:
        return t
    o1 = '            MainRouteTtsAudioCache,\n'
    if o1 not in t:
        print('  [跳补丁·未命中] Navigator3')
        return t
    return t.replace(o1, o1 + '            MainRouteReadAloudSettings,\n', 1)


def f_readaloud_ui_slim(t):
    if 'onClick = onShowReadAloudConfig' not in t:
        return t
    old = ('            ActionButton(\n'
           '                icon = Icons.Default.Settings,\n'
           '                label = stringResource(R.string.setting),\n'
           '                onClick = onShowReadAloudConfig,\n'
           '            )\n')
    if old not in t:
        print('  [跳补丁·未命中] 阅读内去设置按钮')
        return t
    return t.replace(old, '', 1)


patch('app/src/main/java/io/legado/app/ui/main/my/MyScreen.kt', f_my_screen3,
      'MyScreen.kt（+朗读设置入口）')
patch('app/src/main/java/io/legado/app/ui/main/my/MyViewModel.kt', f_my_viewmodel3,
      'MyViewModel.kt（+朗读设置事件）')
patch('app/src/main/java/io/legado/app/ui/main/MainScreen.kt', f_main_screen3,
      'MainScreen.kt（+朗读设置回调）')
patch('app/src/main/java/io/legado/app/ui/main/MainNavGraph.kt', f_main_nav_graph3,
      'MainNavGraph.kt（+朗读设置路由）')
patch('app/src/main/java/io/legado/app/ui/main/MainNavKey.kt', f_main_nav_key3,
      'MainNavKey.kt（+朗读设置路由）')
patch('app/src/main/java/io/legado/app/ui/main/MainNavigator.kt', f_main_navigator3,
      'MainNavigator.kt（+朗读设置分发）')
patch('app/src/main/java/io/legado/app/ui/book/read/sheet/ReadAloudScreen.kt', f_readaloud_ui_slim,
      'ReadAloudScreen.kt（阅读内瘦身）')


# ============================================================
# v1.24：阅读内朗读设置「彻底剔除」（齿轮 + 配置 Sheet + 弹层回落）
# ============================================================
def f_player_gear(t):
    if 'ReadAloudPlayerIntent.OpenSettings' not in t:
        return t
    old = ('                    MediumTonalButton(\n'
           '                        onClick = { onIntent(ReadAloudPlayerIntent.OpenSettings) },\n'
           '                        icon = Icons.Default.Settings,\n'
           '                        contentDescription = stringResource(R.string.setting),\n'
           '                    )\n')
    if old not in t:
        print('  [跳补丁·未命中] 播放器齿轮')
        return t
    return t.replace(old, '', 1)


def f_readbook_screen_v24(t):
    if 'ReadBookSheet.ReadAloudConfig -> ReadAloudPage.Config' not in t:
        return t
    # 1) 配置页映射移除
    old1 = ('    val readAloudPage = when (state.activeSheet) {\n'
            '        ReadBookSheet.ReadAloudConfig -> ReadAloudPage.Config\n'
            '        ReadBookSheet.ReadAloudPlayer -> ReadAloudPage.Player\n'
            '        else -> null\n'
            '    }\n')
    if old1 in t:
        t = t.replace(old1, ('    val readAloudPage = when (state.activeSheet) {\n'
                             '        ReadBookSheet.ReadAloudPlayer -> ReadAloudPage.Player\n'
                             '        else -> null\n'
                             '    }\n'), 1)
    else:
        print('  [跳补丁·未命中] ReadBook 配置页映射')
    # 2) 播放器效应回落改为关闭
    old2 = ('                    ReadAloudPlayerEffect.ReturnToReaderSettings ->\n'
            '                        onIntent(ReadBookIntent.ShowSheet(ReadBookSheet.ReadAloudConfig))\n')
    if old2 in t:
        t = t.replace(old2, ('                    ReadAloudPlayerEffect.ReturnToReaderSettings ->\n'
                             '                        onIntent(ReadBookIntent.DismissSheet)\n'), 1)
    else:
        print('  [跳补丁·未命中] ReadBook 效应回落')
    # 3) 四个数值弹层的 dismiss 目标改为直接关闭
    old3 = ('        onDismissRequest = {\n'
            '            onIntent(ReadBookIntent.ShowSheet(ReadBookSheet.ReadAloudConfig))\n'
            '        },\n')
    n = t.count(old3)
    if n > 0:
        t = t.replace(old3, ('        onDismissRequest = {\n'
                             '            onIntent(ReadBookIntent.DismissSheet)\n'
                             '        },\n'))
    else:
        print('  [跳补丁·未命中] ReadBook 弹层 dismiss')
    if n not in (4,):
        print('  [注意] ReadBook 弹层 dismiss 替换数量 =', n)
    return t


patch('app/src/main/java/io/legado/app/ui/book/readaloud/player/ReadAloudPlayerScreen.kt', f_player_gear,
      'ReadAloudPlayerScreen.kt（去齿轮）')
patch('app/src/main/java/io/legado/app/ui/book/read/ReadBookScreen.kt', f_readbook_screen_v24,
      'ReadBookScreen.kt（剔除朗读配置页）')

print('完成。改动:', changed if changed else '无')
