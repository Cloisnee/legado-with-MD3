#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TTS-Server 移植补丁器（幂等）— 在 legado-with-MD3 的 fork 中运行
用法: python3 apply_patch.py [repo_root]

作用:
  1) settings.gradle(.kts) 注册 modules/lib-common|lib-script|lib-tts
  2) app/build.gradle.kts 增加 implementation(project(":modules:lib-tts"))
  3) App.kt 注入 HostHttp（延迟解析宿主 okHttpClient；找不到锚点时跳过且不报错）
"""
import sys, pathlib

root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else '.')
print('repo root =', root.resolve())
changed = []


def patch(rel, fn, label):
    p = root / rel
    if not p.exists():
        print(f'[跳过] {label}: 找不到 {rel}')
        return
    t = p.read_text(encoding='utf-8')
    nt = fn(t)
    if nt != t:
        p.write_text(nt, encoding='utf-8')
        changed.append(label)
        print(f'[已修改] {label}')
    else:
        print(f'[不动]  {label}（已是目标状态）')


def f_settings_groovy(t):
    mods = [":modules:lib-common", ":modules:lib-script", ":modules:lib-tts"]
    lines = [f"include '{m}'" for m in mods if f"include '{m}'" not in t]
    if not lines:
        return t
    anchor = "include ':modules:rhino'"
    if anchor in t:
        return t.replace(anchor, anchor + "\n" + "\n".join(lines), 1)
    return t.rstrip() + "\n" + "\n".join(lines) + "\n"


def f_settings_kts(t):
    mods = [":modules:lib-common", ":modules:lib-script", ":modules:lib-tts"]
    lines = [f'include("{m}")' for m in mods if f'include("{m}")' not in t]
    if not lines:
        return t
    anchor = 'include(":modules:rhino")'
    if anchor in t:
        return t.replace(anchor, anchor + "\n" + "\n".join(lines), 1)
    return t.rstrip() + "\n" + "\n".join(lines) + "\n"


def f_app_gradle(t):
    line = 'implementation(project(":modules:lib-tts"))'
    if line in t:
        return t
    anchor = 'implementation(project(":modules:rhino"))'
    if anchor in t:
        return t.replace(anchor, anchor + "\n    " + line, 1)
    anchor2 = 'androidTestImplementation(libs.room.testing)'
    if anchor2 in t:
        return t.replace(anchor2, line + "\n    " + anchor2, 1)
    raise SystemExit('[错误] app/build.gradle.kts 未找到依赖插入点')


def f_app_kt(t):
    if 'HostHttp.init' in t:
        return t
    anchor = '        AppConfigStore.init(this)'
    if anchor not in t:
        print('  [警告] App.kt 未找到注入锚点，跳过（移植层将使用内置默认客户端，不影响构建）')
        return t
    inject = (
        anchor
        + "\n        // [TTS-Server 移植] 注入宿主 OkHttpClient（延迟解析，避免初始化顺序问题）"
        + "\n        com.github.jing332.compat.net.HostHttp.init { io.legado.app.help.http.okHttpClient }"
    )
    return t.replace(anchor, inject, 1)


if (root / 'settings.gradle').exists():
    patch('settings.gradle', f_settings_groovy, 'settings.gradle')
elif (root / 'settings.gradle.kts').exists():
    patch('settings.gradle.kts', f_settings_kts, 'settings.gradle.kts')
else:
    print('[跳过] settings 文件不存在')

patch('app/build.gradle.kts', f_app_gradle, 'app/build.gradle.kts')
patch('app/src/main/java/io/legado/app/App.kt', f_app_kt, 'App.kt')

print('完成。改动:', changed if changed else '无')
