# 手机云编译指南（GitHub Actions 白嫖算力 · 全程手机）

> 目标：不用电脑，产出**含 TTS-Server 移植模块**的阅读 APK。
> 原理：你在 GitHub 上建一个 fork，把我们准备好的 `ttsrv-port-overlay.zip` 传上去，
> 然后点一下仓库自带的云编译，GitHub 的服务器帮你编译好，你下载 APK 就行。

---

## 0. 你需要的东西

| 物品 | 说明 |
|---|---|
| GitHub 账号 | 手机浏览器登录即可（没有就先注册，1 分钟） |
| `ttsrv-port-overlay.zip` | 从本对话工作区 `/workspace/ci/` 下载（**不要解压**，原样上传） |
| `build-ttsrv-port.yml` | 同目录下载（用于第 3 步，也可在手机上从 zip 里解出来） |
| MT 管理器 | 可选：用于解压下载的 artifact、后续签名/共存修改、查看文件 |

---

## 1. Fork 主仓库

1. 手机浏览器打开：`https://github.com/HapeLee/legado-with-MD3`
2. 点右上角 **Fork** → 选择你的账号 → 创建（几秒钟）
3. 打开你的 fork：`https://github.com/<你的用户名>/legado-with-MD3`

## 2. 上传移植包

在你的 fork 页面：
1. 点 **Add file → Upload files**
2. 选择 `ttsrv-port-overlay.zip`（不要解压），等到上传完
3. 点 **Commit changes**
4. 确认 zip 在**仓库根目录**（和 `settings.gradle` 同一层）

## 3. 添加构建工作流（二选一）

**方法 A（推荐，省事）**
1. 在 fork 里进入 `.github/workflows` 目录
2. **Add file → Upload files** → 上传 `build-ttsrv-port.yml` → Commit
   （若看不到 `.github` 目录：在仓库地址后手动加上 `/.github/workflows` 也可直达）

**方法 B（没有现成文件时）**
1. **Add file → Create new file**
2. 文件名填：`.github/workflows/build-ttsrv-port.yml`
3. 把 `build-ttsrv-port.yml` 的**全部内容**粘贴进去 → Commit

## 4. 运行云编译

1. fork 顶部标签栏点 **Actions**
2. 第一次会提示启用工作流 → 点 **"I understand my workflows, go ahead and enable them"**
3. 左侧选 **Build TTS-Server Port APK** → 右侧 **Run workflow** → 再点绿色 **Run workflow**
4. 等待 20~60 分钟（首次要下载依赖，比较慢；进度页面实时可看）

## 5. 下载与安装

1. 构建完成（绿色 ✓）→ 点进该次运行 → 页面**底部 Artifacts** 区域
2. 下载 `legado-ttsrv-<编号>`（得到 zip）→ 用 MT 解压 → 得到 `.apk`
3. 直接安装。
   - 这是 debug 构建：包名带 `.debug` 后缀（**与官方版共存**，可同时安装），版本号带 `_debug`
   - 需要"所有文件访问"权限：设置 → 应用 → 阅读(debug) → 特殊权限 → 所有文件访问
     （用于 TTS-Server 数据目录 `Download/chajian`；不授权也能用，会自动回退私有目录）

## 6. 失败了怎么办（常见问题）

| 现象 | 处理 |
|---|---|
| "缺少 ttsrv-port-overlay.zip" | zip 没传到根目录，或名字不对（区分大小写） |
| Gradle 下载依赖超时 / 网络错误 | 直接 **Run workflow** 重跑一次（最常见，重跑就好） |
| 编译报错（代码问题） | 把报错步骤的**文字日志截图**发我，我更新移植包；你重传新 zip 再跑（覆盖上传即可） |
| Actions 标签没有按钮 | 确认工作流文件路径是 `.github/workflows/` 下 |

## 7. 之后怎么更新（重要）

以后每次我更新移植包：
1. 重新下载新版 `ttsrv-port-overlay.zip`
2. 在你 fork 里点开旧 zip → 右上铅笔图标（或直接 Upload files 同名覆盖）→ 上传新版并 Commit
3. Actions → Run workflow → 拿到新 APK（**流程完全一样，1 分钟操作**）

## 8. 关于 MT 管理器的定位（回答"能不能用 MT 做"）

- ❌ MT **不能**把我们的 Kotlin 源码编译成 APK（它只擅长改现成 APK：smali/资源/签名）
- ✅ MT 在这套流程里的用途：解压 artifact、给成品 APK 做共存/改名/去签名校验、抓应用日志、检查文件
- ⚠️ 不建议走"把 TTS-Server 的编译产物直接合并进阅读 APK"的野路子：两边的 okhttp/Rhino/依赖版本互相咬，类冲突会无穷无尽

---

### 附：本包的组成

```
ttsrv-port-overlay.zip
├── modules/                # 三个移植模块（lib-common / lib-script / lib-tts）
├── apply_patch.py          # 自动改仓库（注册模块、加依赖、注入初始化）
├── build-ttsrv-port.yml    # 构建工作流（=第3步要放的文件）
├── README-CI.md            # 本指南
└── TTSRV-PORT-README.md    # 移植层技术说明（给开发者看的）
```
